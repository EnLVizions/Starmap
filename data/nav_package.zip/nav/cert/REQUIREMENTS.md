# navref software requirements (certification-ready track; NOT certified)

Status: **draft, developer-written, not independently reviewed.** Requirement IDs are stable. Each one is verified by the tests named in `TRACEABILITY.md`, which `tools/gen_trace.py` generates from the `Verifies:` tags in `tests/`.
Scope: `navref/navref.py` v0.1.0 (the reference module) and the data files it consumes. Higher-level (system) requirements do not exist yet, because there is no ship system specification. Each requirement below is therefore derived from the user-level need stated in the README ("return target state, intercept aim and current phase for a given ship time").

| ID | Requirement | Rationale / hazard link (FMEA) |
|---|---|---|
| NAV-REQ-001 | The module shall reject catalogue and profile data whose `format` identifier is not the supported one (`pythagoras-nav-catalog-1.0`, `pythagoras-flight-profile-1.0`). | F-01 wrong/old data loaded |
| NAV-REQ-002 | When an expected SHA-256 is supplied, the module shall reject a data file whose checksum differs. | F-01, F-02 corrupted data |
| NAV-REQ-003 | Every public function shall reject non-numeric, boolean, NaN or infinite numeric inputs by raising `NavError`, and shall never return a partial result. | F-03 invalid input |
| NAV-REQ-004 | The module shall reject epochs outside [2016.0, 3000.0] Julian years TDB. | F-07 extrapolation of linear motion |
| NAV-REQ-005 | The module shall reject unknown destination or star identifiers and unknown time-scale names. | F-03 |
| NAV-REQ-006 | `astrometric_to_cartesian` shall agree with an independent implementation (astropy ICRS → Cartesian) within 1e-9 relative in position and 1e-6 km/s in velocity. | F-04 frame/units error |
| NAV-REQ-007 | If a star's radial velocity is missing, the module shall return no velocity and shall refuse to propagate that star. It shall not substitute a value. | F-05 invented data |
| NAV-REQ-008 | `star_state` shall propagate stars by uniform linear motion from the star's reference epoch. Without light-time correction, it shall return the catalogue position exactly at the reference epoch. | F-04 |
| NAV-REQ-009 | When light-time correction is enabled, the geometric position shall equal the propagated catalogue position plus v·d/c. | F-06 aim bias |
| NAV-REQ-010 | For D = 4.24 ly the trip timeline shall reproduce the design document's 33.47 yr Earth and 33.09 yr crew time within 0.01 yr. Boost, magsail and fusion durations shall match the design code within 1e-9 yr. | F-08 profile mismatch |
| NAV-REQ-011 | Interpolated along-track distance, speed and proper time inside the boost and magsail tables shall match the full-resolution design integration within 5e5 km, 0.1 km/s and 1 s. | F-08 |
| NAV-REQ-012 | The reported phase shall be BOOST, CRUISE, MAGSAIL or FUSION using half-open intervals [start, end), with FUSION including the arrival instant. | F-09 wrong phase |
| NAV-REQ-013 | Ship time shall be accepted as Earth (barycentric) time or ship proper time. Converting proper → Earth → proper shall be consistent within 1e-3 s. | F-10 time-scale confusion |
| NAV-REQ-014 | Distance flown shall be non-decreasing in time. Speed shall be continuous within 10 km/s across all phase boundaries. The known steps come from the design code's discretisation: the boost ends 8.2 km/s above 0.23c, and the magsail ends 0.45 km/s below 0.02c. | F-08 |
| NAV-REQ-015 | Ship times below 0 or above the trip duration (in the chosen time scale) shall be rejected. | F-03 |
| NAV-REQ-016 | `intercept` shall converge within 50 iterations to an aim point whose norm equals the flight distance and which equals the target's geometric position at the arrival epoch, within 1 km. Otherwise it shall raise `NavError`. | F-06 |
| NAV-REQ-017 | The intercept arrival epoch shall agree with an independent bisection solution within 1 s. | F-06 |
| NAV-REQ-018 | Outputs shall be deterministic: identical inputs give bit-identical outputs, and the module uses no randomness, clock or environment. | F-11 non-reproducible output |
| NAV-REQ-019 | `nav_state` shall return the documented fields. Ship position shall equal aim_unit × distance flown within 1e-6 km. | F-04 |
| NAV-REQ-020 | A flight distance shorter than the fixed (non-cruise) phases shall be rejected. | F-03 |
| NAV-REQ-021 | The module source shall satisfy the coding rules (CODING_RULES.md), checked automatically: no recursion; only bounded `for` loops (no `while`); standard-library imports `json`, `math`, `hashlib` only; no `global`; no `eval`/`exec`. | F-12 unbounded execution |
| NAV-REQ-022 | Generated OEM files shall follow the OEM layout: version and header keywords, META_START/META_STOP blocks with the required keywords, 7 fields per data line, non-decreasing epochs. Their states shall agree with `navref` within 1 km plus the 1 ms epoch-rounding allowance (≤ 70 km along track), and within 0.07 km/s. | F-13 export error |
| NAV-REQ-023 | Stored catalogue Cartesian states shall equal values recomputed from the stored astrometry within 1e-9 relative. Manifest checksums shall match the files. | F-02 |
| NAV-REQ-024 | The module, the manifest and every generated JSON and OEM file shall carry the notice "NOT FLIGHT-CERTIFIED" (CSV files carry it via README and manifest). | F-14 misuse as certified software |
