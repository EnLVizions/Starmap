# navref coding rules (in the spirit of NASA/JPL "Power of Ten", adapted to Python)

These rules come from G. J. Holzmann, "The Power of Ten – Rules for Developing Safety-Critical Code" (IEEE Computer 39(6), 2006, NASA/JPL Laboratory for Reliable Software). The original rules target C, so the Python equivalents below are **our adaptation**. Rules marked **[auto]** are checked by `tests/test_navref.py::check_coding_rules` (NAV-REQ-021). The others were checked by developer review only; no independent review has been done.

| # | Power-of-Ten rule (paraphrased) | navref rule | Check |
|---|---|---|---|
| 1 | Simple control flow; no goto, setjmp or recursion | No recursion (direct recursion detected by AST). No exceptions used for control flow: `NavError` is raised only for rejection. | [auto] recursion; review |
| 2 | Every loop has a fixed upper bound | No `while`. Every `for` iterates over `range(<constant bound>)` or a literal tuple. Bounds: `MAX_INTERCEPT_ITER`=50, `MAX_SEARCH_ITER`=64, `MAX_TABLE_ROWS`, `MAX_STARS`, `MAX_HASH_CHUNKS`. Exceeding a bound raises `NavError`. | [auto] |
| 3 | No dynamic memory after initialisation | Not enforceable in CPython. Data are loaded once (`load_*`); query functions allocate only small fixed-size tuples and dicts. | review (gap) |
| 4 | Functions ≤ ~60 lines | All functions ≤ 60 lines | review |
| 5 | ≥ 2 assertions per function | Replaced by explicit input validation that raises `NavError`. Python `assert` is stripped under `-O`, so it is not used for checks. Every public function validates every argument. | review + NAV-REQ-003 tests |
| 6 | Smallest possible data scope | No module-level mutable state; constants only. No `global`. | [auto] global |
| 7 | Check return values and parameters | All inputs are validated (`_finite`, `_vec3`, `_epoch`, id lookups). No partial results are returned. | NAV-REQ-003/004/005 tests |
| 8 | Limited preprocessor | No `eval`, `exec`, `compile` or `__import__`. No dynamic import. | [auto] |
| 9 | Restricted pointers / indirection | No function pointers in data, no monkey-patching in production code, no reflection | review |
| 10 | All warnings on; static analysers clean | `python -W error` for tests. Allowed imports: `json`, `math`, `hashlib` only [auto]. A full static-analysis tool chain (e.g. mypy --strict, pylint, bandit) is **not yet run**: this is a gap. | [auto] imports; gap |

Additional rules:
- **Determinism (NAV-REQ-018).** No randomness, clock, environment or OS access in the module.
- **Units.** Units are in names (`_km`, `_km_s`, `_s`, `_jyr`). No unit-less physical quantities in the API.
- **Errors.** Each error message names the offending input.
