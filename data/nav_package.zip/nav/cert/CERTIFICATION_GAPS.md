# Certification gaps: navref reference module

**This software is NOT certified, qualified or approved by anyone.** This file maps the evidence that exists now to two frameworks and lists what is still needed. The two frameworks are **NASA NPR 7150.2D, Software Class A** (human-rated space flight) and **RTCA DO-178C, Level (DAL) A**. DO-178C is an airborne-software standard; it is listed only as a widely used benchmark for the most critical level. All evidence here was produced by the developer, a single AI assistant, with **no independence**. That alone disqualifies it from either framework's Class A / Level A credit.

Framework facts used:
- **NPR 7150.2D:**
  - SWE-052: bidirectional traceability (Table 1; Class A–C).
  - SWE-134: safety-critical software behaviours.
  - SWE-219: 100% MC/DC coverage for safety-critical components.
  - SWE-141: IV&V for projects selected by NASA; the selection criteria are in NPR 7120.5/NASA IV&V policy.
  - Sources: NPR 7150.2D text on nodis3.gsfc.nasa.gov and the NASA SWE Handbook (swehb.nasa.gov).
- **DO-178C Level A:**
  - 71 Annex A objectives (Tables A-1 to A-10), about 30 of them with independence. Secondary sources give 30 or 31.
  - Requires MC/DC, decision and statement coverage.
  - Requires verification of object code not traceable to source (A-7 obj. 9).
  - Sources: secondary summaries of RTCA DO-178C. The standard itself was not consulted; it is a paid RTCA document.

## 1. Evidence produced so far

| Artefact | File | Result |
|---|---|---|
| Software requirements (24, with IDs) | `cert/REQUIREMENTS.md` | Developer-written, unreviewed |
| Unit and verification tests | `tests/test_navref.py`, `tests/test_package.py` | 50 cases (32 test functions), 50 pass with warnings treated as errors (`cert/test_results.xml`) |
| Structural coverage | `cert/coverage.json` | 100% statement (281/281), 100% branch (98/98) on `navref/navref.py` (coverage.py). **MC/DC not measured.** |
| Traceability requirements ↔ tests | `cert/TRACEABILITY.md` (generated) | 24/24 requirements have ≥ 1 passing test; 0 orphan tests |
| Coding standard + automatic checks | `cert/CODING_RULES.md` | Recursion, `while`, imports, `global`, `eval`/`exec` checked automatically |
| FMEA | `cert/FMEA.md` | 16 failure modes, developer-rated |
| Data integrity | `manifest.json` (SHA-256), REQ-002/023 tests | Pass |
| Independent cross-checks | astropy (astrometry), own bisection solver (intercept), design code (profile) | Pass. These are independent *implementations*, but not independent *people*. |

## 2. Mapping to NPR 7150.2D (Class A)

| NPR 7150.2D item | Status | Gap |
|---|---|---|
| Software classification and safety criticality (SWE-020, SWE-205) | Not done | Needs a system hazard analysis to classify the software; Class A is assumed here only as the target |
| Software plans: development, SA, CM, V&V (SWE-013 and related) | Not done | No SDP, SAP, SCMP or verification plan |
| Software requirements (SWE-050, SWE-051) | Partial | Derived from a user-level need, not from system requirements. No requirements review. |
| Bidirectional traceability (SWE-052) | Partial | Requirements ↔ tests done. Requirements ↔ hazards are partial (FMEA links). No higher-level requirements, design components or non-conformance traces. |
| Safety-critical behaviours (SWE-134) | Partial | Input validation, reject-on-error and bounded execution exist. Safe-state transitions, out-of-sequence command rejection and timing response are **system-integration items** and are not done. |
| Design (SWE-057, SWE-058) | Not done | No architecture or detailed design document beyond docstrings |
| Coding standard (SWE-061) | Partial | Power-of-Ten-inspired rules; partly automated; no static-analysis tool suite (SWE-135) |
| Unit testing (SWE-062) | Done (developer level) | Repeatable, but no independent test witnessing |
| Code coverage, 100% MC/DC for safety-critical (SWE-219) | **Gap** | Statement and branch coverage are 100%. No MC/DC tool was run. A qualified MC/DC measurement (e.g. on a compiled target implementation) is required. |
| Verification and validation, incl. on target hardware (SWE-066, SWE-073) | **Gap** | Host-only testing; no target processor, no hardware-in-the-loop (HIL), no end-to-end with real sensors |
| Software assurance and IV&V (SWE-022, SWE-141, NASA-STD-8739.8) | **Gap** | No software assurance organisation; no IV&V |
| Configuration management (SWE-079–SWE-085) | Partial | Versioned data (`data_version`, `navref_version`, SHA-256 manifest); no CM system, baselines or change control |
| Cybersecurity (SWE-156 and related) | Not done | No threat assessment of data loading |
| Acceptance and authority approval | Not done | Requires a NASA Technical Authority / project approval |

## 3. Mapping to DO-178C Level A (Annex A)

| Table | Objective area | Status | Gap |
|---|---|---|---|
| A-1 | Planning (PSAC, SDP, SVP, SCMP, SQAP, standards) | Not done | All plans missing; coding standard only |
| A-2 | Development (HLR, LLR, architecture, source, EOC) | Partial | HLR ≈ REQUIREMENTS.md. No LLR or architecture document. "Executable object code" is CPython bytecode, which is unsuited to Level A. |
| A-3 | Verification of requirements (accuracy, consistency, verifiability, traceability), several with independence | Not done | Needs independent review |
| A-4 | Verification of design | Not done | No design to verify |
| A-5 | Verification of code (compliance, accuracy, standards, traceability) | Partial | Automatic rule checks; no independent code review |
| A-6 | Testing (normal, robustness; HLR and LLR; compatibility with target) | Partial | Normal and robustness tests vs HLR on host; none on target hardware |
| A-7 | Verification of verification (test coverage of HLR and LLR, MC/DC, decision, statement, data/control coupling, untraceable object code) | Partial | Statement and decision 100% on source. **MC/DC, data and control coupling analysis, and object-code verification are missing.** |
| A-8 | Configuration management | Partial | Checksums and versions only |
| A-9 | Quality assurance (with independence) | Not done | No SQA |
| A-10 | Certification liaison (PSAC, SAS, authority agreement) | Not done | No certification authority. No authority currently certifies crewed interstellar flight software. |

## 4. What still requires independent work

1. **Independent V&V (IV&V):** a separate organisation reviews the requirements, design and code, re-derives the astrometry and intercept independently, and writes its own tests.
2. **Hardware-in-the-loop (HIL):** the module, or its re-implementation in a flight language, runs on the target processor with real-time scheduling, worst-case execution time (WCET) measurement, fault injection, and simulated star-tracker and clock inputs.
3. **Target implementation:** Python/CPython is not a credible Level A / Class A runtime (garbage collection, interpreter not qualified). Expect a re-implementation in a restricted language subset (e.g. MISRA C or SPARK Ada) with a qualified toolchain. Re-run all tests on it, with MC/DC.
4. **System-level work:**
   - hazard analysis and a system safety assessment (ARP4761A-style or NASA safety process) to set the software level
   - a system requirements specification
   - an interface control document (ICD) with the guidance, navigation and control computer
5. **Data qualification:**
   - an independent astrometric cross-check of every destination (second catalogue, epoch checks)
   - a signed data-release process
   - binary-orbit models where relevant, e.g. Proxima around α Cen AB
6. **Authority review:** NASA Technical Authority (NPR 7150.2D) or a certification authority (DO-178C via its PSAC/SAS process). No such approval exists or has been sought.
