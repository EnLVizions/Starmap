# Pythagoras navigation data package and flight simulator

> **DESIGN AND REFERENCE DATA AND SOFTWARE: NOT FLIGHT-CERTIFIED.**
> - This is a design-study package built on the Pythagoras star map: v2 for 50 ly, v1.2 for 20 ly.
> - It is **not integrated with, and makes no claim of compatibility with, any real vehicle, company or flight-software system.**
> - It provides standard-format, ingestible data (JSON, CSV, CCSDS-OEM-style text), a reference Python module and an offline simulator.
> - The flight profile is the **speculative** Pythagoras Concept Design v2.4 §4.7 profile.
> - A certification-*ready* evidence track is in `cert/`. Nothing here is certified; see `cert/CERTIFICATION_GAPS.md`.

## Contents

| Path | What |
|---|---|
| `data/star_catalog.json` / `.csv` | 1480 objects of the 1267 v2 systems (≤ 50 ly). ICRS astrometry with uncertainties (Gaia DR3 at epoch 2016.0; SIMBAD at J2000.0 where Gaia is not used). Barycentric Cartesian position (km, ly, AU, pc) and velocity (km/s, AU/yr). CSV also gives positions at 2016.0 and at the departure epoch. 1159 have full 3-D velocity; 321 lack RV, so they have **no** velocity (never guessed). |
| `data/intercepts.json` / `.csv` | Per destination: arrival epoch, intercept aim point, aim shift, miss distance if the star's motion were ignored, light-time term, Monte-Carlo 1σ, Δv to match the star |
| `data/waypoints.json` / `.csv` | Departure, end of boost, start of magsail, start of fusion brake, arrival. Each has TDB epoch, Earth and proper elapsed time, β and the state vector. |
| `trajectories/<dest>.csv` / `.json` | Time-stamped state vectors with phase labels. Earth time grid: boost 0.05 yr, cruise 0.5 yr, magsail 0.1 yr, fusion 0.05 yr. Each sample also gives ship proper time. |
| `oem/<dest>.oem` | CCSDS OEM-style text (one segment per phase; TDB, ICRF, SSB-centred, km and km/s, 13 significant digits) |
| `data/route_hazards.json` / `.csv` | LISM clouds traversed and near (**projection only**), the design's assumed ISM density, derived column density, ISM proton energy in the ship frame |
| `data/guide_stars.csv` | 152 optical-navigation guide stars (Hipparcos 2007, Hp < 3.5, standard 5-parameter solutions, position errors < 1 mas). 70 have parallax > 20 mas and are useful for parallax position fixes. |
| `data/aberration_doppler_0.23c.csv` | Aberration and Doppler versus angle at 0.23c |
| `data/guide_star_views_cruise.csv` | Per destination at mid-cruise, each guide star's parallax shift, angle from the velocity vector (rest and ship frame), aberration and Doppler factor |
| `data/flight_profile.json` | Boost, magsail and fusion phase tables extracted from the design-document code (cruise is analytic) |
| `navref/` | Reference Python module (standard library only) |
| `examples/query_example.py` | Example: load the package and query a ship time |
| `sim.html` | Self-contained offline Three.js flight simulator. Screenshots: `sim.png` (Proxima, mid-flight, with sky view) and `sim_sky_teegarden.png` (cruise at 0.23c, 150° forward sky). |
| `manifest.json` | Data version, departure epoch and SHA-256 of every data file |
| `cert/` | Requirements, traceability, test results, coverage, coding rules, FMEA, certification gaps |
| `tools/` | Build scripts. `fetch_nav.py` does the archive queries, `make_profile.py`, `build_nav.py`, `build_sim.py`, `run_cert_checks.sh`. |
| `raw/` | Raw archive responses plus `_meta.json` (endpoint, query, UTC time, rows) |

**Rebuild:**
- Data: `NAV_DEPARTURE_EPOCH=2032.0 ../.venv/bin/python tools/build_nav.py`. The departure epoch is configurable; the default is **2032.0**.
- Simulator and PNGs: `../.venv/bin/python tools/build_sim.py`.
- Certification-track evidence: `tools/run_cert_checks.sh`.
- `navref.intercept()` / `nav_state()` accept any departure epoch at run time, so a new build is needed only for the pre-computed files.

## Destinations and key numbers (departure J2032.0 TDB)

The destinations are the union of the v2 (50 ly) top 10 and the v1.2 (20 ly) top 10, so 11 stars. The v1.2 list has GJ 411 (HD 95735) at #10 instead of GJ 1002.

| Destination | v2 rank | v1.2 rank | Flight (ly) | Arrival (TDB) | Earth / crew yr | Aim shift (″) | Miss if aimed at apparent position (AU) | Star moves during flight (AU) | Light-time term (AU) | 1σ transverse / along-LOS (AU) | Δv to match star (km/s) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Proxima Centauri | 1 | 1 | 4.243 | 2065-06-25 (J2065.48) | 33.48 / 33.10 | 145.8 | 190 | 229 | 29.0 | 0.006 / 17.2 | 32.4 |
| Teegarden's Star | 2 | 3 | 12.518 | 2101-06-18 (J2101.46) | 69.46 / 68.12 | 419.1 | 1609 | 1647 | 296.3 | 0.337 / 295.2 | 112.4 |
| HD 173740 | 3 | 2 | 11.491 | 2096-12-30 (J2097.00) | 65.00 / 63.78 | 178.2 | 628 | 534 | 94.4 | 0.037 / 71.6 | 38.9 |
| HD 265866 | 4 | 9 | 18.224 | 2126-04-11 (J2126.27) | 94.27 / 92.27 | 93.2 | 521 | 622 | 120.2 | 0.057 / 181.7 | 31.3 |
| CD-44 11909 | 5 | 8 | 16.319 | 2117-12-28 (J2117.99) | 85.99 / 84.20 | 120.2 | 602 | 810 | 153.9 | 0.060 / 158.5 | 44.7 |
| Luyten's star | 6 | 6 | 12.354 | 2100-10-02 (J2100.75) | 68.75 / 67.43 | 302.8 | 1147 | 1004 | 180.4 | 0.099 / 117.1 | 69.3 |
| Ross 128 | 7 | 4 | 10.998 | 2094-11-09 (J2094.85) | 62.85 / 61.69 | 100.9 | 340 | 499 | 87.4 | 0.021 / 71.9 | 37.6 |
| L 372-58 | 8 | 7 | 11.984 | 2099-02-22 (J2099.14) | 67.14 / 65.86 | 66.0 | 242 | 207 | 36.9 | 0.018 / 87.9 | 14.6 |
| Lacaille 9352 | 9 | 5 | 10.727 | 2093-09-03 (J2093.67) | 61.67 / 60.54 | 499.1 | 1641 | 1402 | 243.9 | 0.063 / 45.2 | 107.8 |
| G 158-27 | 10 |  | 15.790 | 2115-09-11 (J2115.69) | 83.69 / 81.97 | 205.2 | 993 | 1099 | 207.6 | 0.131 / 220.3 | 62.3 |
| HD 95735 |  | 10 | 8.283 | 2083-01-19 (J2083.05) | 51.05 / 50.20 | 286.4 | 727 | 1109 | 180.4 | 0.031 / 42.3 | 103.0 |
**Definitions:**
- **Aim shift:** the angle between the star's *apparent* direction at departure (catalogue position propagated to the departure epoch, as seen from the Sun) and the intercept direction.
- **Intercept direction:** toward the star's *geometric* position at the arrival epoch. Finding it accounts for the star's motion during the flight and for light-time (the star's light is d/c old).
- **Miss distance:** the perpendicular distance from the intercept point to the apparent-direction ray.
- **1σ:** Monte Carlo over 1000 draws of the catalogue parallax, proper-motion and RV errors, with Gaia correlations. Seed fixed, so results are reproducible.

## Interface specification (navigation subsystem module: reference only)

**Role:**
- A navigation-data provider for a hypothetical ship guidance, navigation and control (GNC) computer.
- **Inputs:** the static data files plus a query (destination, departure epoch, ship time and time scale).
- **Outputs:** target-star state, intercept aim and the current flight phase with the nominal ship state.
- It **does not** read sensors, estimate state, command actuators or schedule phase changes. Those are the host system's job and are outside scope.

| Item | Specification |
|---|---|
| **Static inputs** | `data/star_catalog.json` (format `pythagoras-nav-catalog-1.0`) and `data/flight_profile.json` (`pythagoras-flight-profile-1.0`). SHA-256 values come from `manifest.json`. Loaded once with `navref.load_catalog(path, sha256)` / `navref.load_profile(path, sha256)`. |
| **Query inputs** | `dest_id` (str, e.g. `proxima-centauri`). `departure_epoch` (float, Julian years TDB, allowed 2016.0–3000.0). `ship_time_s` (float s since departure, 0 to trip duration). `time_scale` ∈ {`"earth"` (barycentric coordinate time, TDB-like), `"proper"` (ship proper time)}. |
| **Outputs** | `nav_state(...)` returns a dict with these fields: `phase` ∈ {BOOST, CRUISE, MAGSAIL, FUSION}, `epoch_tdb_jyr`, `earth_elapsed_s`, `proper_elapsed_s`, `ship_pos_km[3]`, `ship_vel_km_s[3]`, `beta`, `gamma`, `distance_flown_km`, `distance_remaining_km`, `target_pos_km[3]`, `target_vel_km_s[3]`, `aim_point_km[3]`, `aim_unit[3]`, `arrival_epoch`, `aim_shift_vs_apparent_arcsec`, `navref_version`, `catalog_version`. `intercept(...)` additionally returns the phase timeline, miss distance, light-time term, Δv to match the star and the iteration count. Errors raise `navref.NavError`; no partial results are returned. |
| **Coordinate frame** | Barycentric ICRS (BCRS axes), Cartesian. x → RA 0h, Dec 0°; z → north celestial pole. Origin is the Solar System barycentre; the departure point is taken as the SSB (the Earth–SSB offset of ≈ 1 AU is neglected). Ship trajectory is a straight line from the SSB to the intercept point. |
| **Units** | km, km/s, s; epochs in Julian years TDB (J2000.0 = 2000.0, 1 yr = 365.25 d). Light-year = c × Julian year = 9.4607304725808e12 km. AU = 149597870.7 km. pc = 648000/π AU. Angles in degrees, or arcsec where named. |
| **Star model** | Uniform linear motion from each star's reference epoch. Geometric position = catalogue (as-observed) position + v·d/c (light-time). No binary-orbit, Galactic-acceleration or relativistic-astrometry terms. |
| **Update rate** | Stateless and deterministic, so it can be called at any rate. Reference cost on the build box (CPython 3.13): `nav_state` ≈ 0.03–0.05 ms per call (2000-call average). This is **not** a worst-case execution time (WCET) on any target. Data change only with a new data release. Expected use: re-evaluate the intercept when the catalogue or departure epoch changes, and query `nav_state` at the host's GNC rate. |
| **Data versioning** | `manifest.json`: `data_version` (currently `nav-2026.10.17-1`), `navref_version` (`0.1.0`), `departure_epoch_jyr`, and a SHA-256 per file. Format strings are versioned (`...-1.0`); the module rejects other versions. Any change to astrometry, profile or departure epoch is a new `data_version`. Outputs echo `navref_version` and `catalog_version`. |
| **Error handling** | Invalid, non-finite, out-of-range or unknown inputs, a distance shorter than the fixed phases, intercept non-convergence (> 50 iterations) and checksum mismatch all raise `NavError`. The host must define the safe response; this is not provided. |
| **Implementation constraints** | Python standard library only (`json`, `math`, `hashlib`). No recursion, bounded loops, no global state, no I/O outside `load_*`. See `cert/CODING_RULES.md`. |

## Assumptions (all labelled; nothing invented)

1. **Flight profile: design document v2.4 §4.7, 20 kt ship, propellant carried.**
   - Laser boost at 0.1 g with constant beam power (Doppler-limited), reaching 0.23c in 2.924 yr Earth / 2.894 yr crew over 0.367 ly.
   - Coast at 0.23c.
   - 3,000 km magsail brake from 0.23c to 0.02c in 22.517 yr over 2.452 ly. Assumes a **uniform n_i = 0.1 cm⁻³**.
   - D–³He fusion brake at a constant 0.01 g proper deceleration, from 0.02c to rest in 1.938 yr over 0.019 ly.
   - The tables were produced by re-running the design code (`calc_faststop.laser_leg`, `calc_shield_sail.magsail`, `calc_faststop.rocket_leg`), so they reproduce its numbers exactly. At D = 4.24 ly the trip is 33.47 / 33.09 yr, as in the doc.
   - The design code's discretisation leaves two small speed steps: the boost ends 8.2 km/s above 0.23c, and the magsail ends 0.45 km/s below 0.02c.
2. **Not modelled:**
   - flip and sail jettison (taken as instantaneous)
   - E-sail / stellar-wind capture
   - matching the target star's velocity (the Δv column)
   - the effect of real ISM structure on magsail drag
   - gravity of the Sun or the target
3. **Geometry:**
   - The ship departs from the SSB and flies a straight line to the intercept point.
   - It ends at rest in the barycentric frame.
4. **Proper time:**
   - Proper time is the design code's: midpoint rule in the magsail table, analytic for the fusion leg, constant γ = 1.02755 in cruise.
   - Gravitational time dilation is ignored.
5. **Hazards:**
   - LISM clouds come from the Redfield & Linsky (2008) calculator for the **system primary's** sight line. This is the same lookup as the star map; for Proxima it uses α Cen's direction, about 2° away.
   - The result is projection only: no cloud distances, so a "traversed" cloud may lie beyond the target, and the order of crossings is unknown. The simulator therefore lists clouds and does not draw them.
   - Column density = n_i × distance under the uniform-density assumption.
   - Dust hazard: unknown.
6. **Guide stars and sky:**
   - Hipparcos 2007 positions are at epoch J1991.25 and are not propagated in `guide_stars.csv`. Proper motions are given, but Hipparcos has no RV.
   - Sky colours: black body at δ·T. T comes from B−V (Ballesteros 2012) or a nominal spectral-class temperature.
   - Brightness uses δ⁴ (bolometric) and is illustrative.
7. **Uncertainty:** the Monte-Carlo 1σ covers catalogue errors only. Model errors are not included: binary orbits, and the linear-motion approximation over about 100 yr.
