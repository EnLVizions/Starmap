"""navref: reference navigation module for the Pythagoras star-map navigation data package.

    *** DESIGN AND REFERENCE DATA / REFERENCE SOFTWARE. NOT FLIGHT-CERTIFIED. ***
    Not qualified, not independently verified, not approved by any authority. It is not integrated
    with, and makes no claim of compatibility with, any real vehicle or flight-software system.

Purpose: load the package's star catalogue and flight profile, and return for a given ship time
the target-star state, the intercept aim point and the current flight phase.

Frames / units (see README "Interface specification"):
  * Positions: barycentric ICRS Cartesian, km (x -> RA 0h Dec 0, z -> north celestial pole).
  * Velocities: km/s in the same frame.  Epochs: Julian years in TDB (J2000.0 = 2000.0).
  * Ship time: seconds since departure, either Earth/barycentric coordinate time ("earth")
    or ship proper time ("proper").
Coding rules (CODING_RULES.md): no recursion, every loop bounded by a constant, every public input
validated, no global mutable state, no randomness, no I/O except the explicit load functions.
"""
import json
import math
import hashlib

NAVREF_VERSION = "0.1.0"
CATALOG_FORMAT = "pythagoras-nav-catalog-1.0"
PROFILE_FORMAT = "pythagoras-flight-profile-1.0"

C_KM_S = 299792.458                  # exact (SI)
JYEAR_S = 31557600.0                 # Julian year, exact
LY_KM = C_KM_S * JYEAR_S             # IAU light-year 9.4607304725808e12 km
AU_KM = 149597870.7                  # IAU 2012, exact
PC_KM = AU_KM * 648000.0 / math.pi   # parsec
K_KMS = AU_KM / JYEAR_S              # 1 AU/yr in km/s (4.740470463...)
MAS_TO_RAD = math.pi / (180.0 * 3600.0 * 1000.0)

EPOCH_MIN = 2016.0                   # earliest allowed departure / evaluation epoch (Gaia DR3 reference epoch)
EPOCH_MAX = 3000.0                   # latest allowed epoch (linear star motion assumed; see FMEA F-07)
MAX_INTERCEPT_ITER = 50              # bound for the intercept fixed-point iteration
INTERCEPT_TOL_KM = 1.0               # convergence tolerance on the flight distance
MAX_SEARCH_ITER = 64                 # bound for binary searches (2**64 > any table length)
MAX_TABLE_ROWS = 100000              # bound for loops over profile tables
MAX_STARS = 100000                   # bound for loops over the catalogue
MAX_HASH_CHUNKS = 1 << 20            # bound for checksum reads (1 MiB chunks -> files up to 1 TiB)
TIME_SCALES = ("earth", "proper")


class NavError(ValueError):
    """Raised for any invalid input or data; the module never returns a partial result."""


# ----------------------------------------------------------------------------- validation helpers
def _finite(x, name):
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        raise NavError(f"{name} must be a number, got {type(x).__name__}")
    xf = float(x)
    if not math.isfinite(xf):
        raise NavError(f"{name} must be finite, got {x!r}")
    return xf


def _vec3(v, name):
    if not isinstance(v, (list, tuple)) or len(v) != 3:
        raise NavError(f"{name} must be a 3-vector")
    return (_finite(v[0], name), _finite(v[1], name), _finite(v[2], name))


def _epoch(e, name="epoch"):
    ef = _finite(e, name)
    if ef < EPOCH_MIN or ef > EPOCH_MAX:
        raise NavError(f"{name} {ef} outside allowed range [{EPOCH_MIN}, {EPOCH_MAX}]")
    return ef


def _norm(v):
    return math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])


def _angle_rad(a, b):
    """Angle between two non-zero vectors (atan2 form, accurate for tiny angles)."""
    cx = a[1] * b[2] - a[2] * b[1]
    cy = a[2] * b[0] - a[0] * b[2]
    cz = a[0] * b[1] - a[1] * b[0]
    return math.atan2(math.sqrt(cx * cx + cy * cy + cz * cz), a[0] * b[0] + a[1] * b[1] + a[2] * b[2])


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for _ in range(MAX_HASH_CHUNKS):
            chunk = f.read(1 << 20)
            if not chunk:
                return h.hexdigest()
            h.update(chunk)
    raise NavError(f"{path}: larger than the checksum read bound")


# ----------------------------------------------------------------------------- astrometry
def astrometric_to_cartesian(ra_deg, dec_deg, parallax_mas, pmra_mas_yr, pmdec_mas_yr, rv_km_s):
    """ICRS astrometry -> barycentric Cartesian position (km) and velocity (km/s).
    pmra is mu_alpha* (includes cos dec). rv may be None: the velocity is then None (not guessed)."""
    ra = math.radians(_finite(ra_deg, "ra_deg"))
    dec = math.radians(_finite(dec_deg, "dec_deg"))
    plx = _finite(parallax_mas, "parallax_mas")
    if plx <= 0.0:
        raise NavError("parallax_mas must be > 0")
    if abs(dec) > math.pi / 2:
        raise NavError("dec_deg out of range")
    d_km = PC_KM * 1000.0 / plx
    cr, sr, cd, sd = math.cos(ra), math.sin(ra), math.cos(dec), math.sin(dec)
    rhat = (cd * cr, cd * sr, sd)
    pos = (d_km * rhat[0], d_km * rhat[1], d_km * rhat[2])
    if rv_km_s is None:
        return pos, None
    rv = _finite(rv_km_s, "rv_km_s")
    pa = _finite(pmra_mas_yr, "pmra_mas_yr")
    pd = _finite(pmdec_mas_yr, "pmdec_mas_yr")
    d_pc = 1000.0 / plx
    vt_a = K_KMS * d_pc * pa / 1000.0      # km/s along east
    vt_d = K_KMS * d_pc * pd / 1000.0      # km/s along north
    ehat = (-sr, cr, 0.0)
    nhat = (-sd * cr, -sd * sr, cd)
    vel = tuple(rv * rhat[i] + vt_a * ehat[i] + vt_d * nhat[i] for i in range(3))
    return pos, vel


# ----------------------------------------------------------------------------- loading
def load_catalog(path, expected_sha256=None):
    if expected_sha256 is not None and sha256_file(path) != expected_sha256:
        raise NavError(f"checksum mismatch for {path}")
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    return validate_catalog(raw)


def validate_catalog(raw):
    if not isinstance(raw, dict) or raw.get("format") != CATALOG_FORMAT:
        raise NavError(f"catalogue format must be {CATALOG_FORMAT}")
    stars = raw.get("stars")
    if not isinstance(stars, list) or not 0 < len(stars) <= MAX_STARS:
        raise NavError("catalogue has no stars or too many")
    out = {}
    for i in range(len(stars)):
        s = stars[i]
        sid = s.get("id") if isinstance(s, dict) else None
        if not isinstance(sid, str) or not sid or sid in out:
            raise NavError(f"bad or duplicate star id at row {i}")
        pos = _vec3(s.get("pos_km"), f"{sid}.pos_km")
        vel = None if s.get("vel_km_s") is None else _vec3(s.get("vel_km_s"), f"{sid}.vel_km_s")
        ep = _finite(s.get("ref_epoch"), f"{sid}.ref_epoch")
        if ep < 1990.0 or ep > 2100.0:
            raise NavError(f"{sid}.ref_epoch implausible")
        if _norm(pos) <= 0.0:
            raise NavError(f"{sid}: zero position")
        out[sid] = dict(id=sid, name=str(s.get("name", sid)), pos_km=pos, vel_km_s=vel, ref_epoch=ep)
    dests = raw.get("destinations")
    if not isinstance(dests, list) or not dests:
        raise NavError("catalogue has no destinations")
    dmap = {}
    for j in range(min(len(dests), MAX_STARS)):
        d = dests[j]
        did, sid = d.get("id"), d.get("star_id")
        if not isinstance(did, str) or did in dmap or sid not in out:
            raise NavError(f"bad destination at row {j}")
        if out[sid]["vel_km_s"] is None:
            raise NavError(f"destination {did} has no full velocity (radial velocity missing)")
        dmap[did] = dict(id=did, star_id=sid, name=str(d.get("name", did)))
    return dict(format=CATALOG_FORMAT, version=str(raw.get("data_version", "")), stars=out, destinations=dmap,
                light_time_correction=bool(raw.get("light_time_correction", True)))


def load_profile(path, expected_sha256=None):
    if expected_sha256 is not None and sha256_file(path) != expected_sha256:
        raise NavError(f"checksum mismatch for {path}")
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    return validate_profile(raw)


def _check_table(p):
    name = p.get("name")
    cols = [p.get(k) for k in ("t_s", "x_km", "v_km_s", "tau_s")]
    n = len(cols[0]) if isinstance(cols[0], list) else 0
    if n < 2 or n > MAX_TABLE_ROWS or any((not isinstance(c, list)) or len(c) != n for c in cols):
        raise NavError(f"phase {name}: bad table")
    t, x, v, tau = ([_finite(z, f"{name} table") for z in c] for c in cols)
    for i in range(1, n):
        if not (t[i] > t[i - 1] and x[i] >= x[i - 1] and tau[i] > tau[i - 1]):
            raise NavError(f"phase {name}: table not monotonic at row {i}")
    for i in range(n):
        if v[i] < 0.0 or v[i] >= C_KM_S:
            raise NavError(f"phase {name}: speed out of range at row {i}")
    if t[0] != 0.0 or x[0] != 0.0 or tau[0] != 0.0:
        raise NavError(f"phase {name}: table must start at zero")
    return dict(name=name, t=t, x=x, v=v, tau=tau, n=n)


def validate_profile(raw):
    if not isinstance(raw, dict) or raw.get("format") != PROFILE_FORMAT:
        raise NavError(f"profile format must be {PROFILE_FORMAT}")
    ph = raw.get("phases")
    if not isinstance(ph, list) or [p.get("name") for p in ph] != ["BOOST", "MAGSAIL", "FUSION"]:
        raise NavError("profile must contain phases BOOST, MAGSAIL, FUSION in that order")
    tabs = [_check_table(ph[i]) for i in range(3)]
    vc = _finite(raw.get("cruise", {}).get("v_km_s"), "cruise.v_km_s")
    if not 0.0 < vc < C_KM_S:
        raise NavError("cruise speed out of range")
    return dict(format=PROFILE_FORMAT, boost=tabs[0], magsail=tabs[1], fusion=tabs[2], v_cruise=vc,
                gamma_cruise=1.0 / math.sqrt(1.0 - (vc / C_KM_S) ** 2))


# ----------------------------------------------------------------------------- star states
def star_state(cat, star_id, epoch, light_time=None):
    """Geometric barycentric state of a star at `epoch` (Julian yr TDB), linear (uniform) motion.
    With light-time correction (default from catalogue) the catalogue's as-observed position is moved
    forward by v*d/c, i.e. to where the star actually is at `epoch`."""
    if star_id not in cat["stars"]:
        raise NavError(f"unknown star {star_id!r}")
    ep = _epoch(epoch)
    s = cat["stars"][star_id]
    if s["vel_km_s"] is None:
        raise NavError(f"{star_id}: no velocity vector (radial velocity missing)")
    lt = cat["light_time_correction"] if light_time is None else bool(light_time)
    dt_s = (ep - s["ref_epoch"]) * JYEAR_S
    p, v = s["pos_km"], s["vel_km_s"]
    pos = [p[i] + v[i] * dt_s for i in range(3)]
    if lt:
        tau_light = _norm(pos) / C_KM_S
        pos = [pos[i] + v[i] * tau_light for i in range(3)]
    return tuple(pos), tuple(v)


# ----------------------------------------------------------------------------- flight profile
def _seg_index(arr, n, value):
    """Index i with arr[i] <= value <= arr[i+1] (binary search, bounded)."""
    lo, hi = 0, n - 1
    for _ in range(MAX_SEARCH_ITER):
        if hi - lo <= 1:
            return lo
        mid = (lo + hi) // 2
        if arr[mid] <= value:
            lo = mid
        else:
            hi = mid
    raise NavError("search did not terminate")  # unreachable for n <= 2**64


def _hermite(t0, t1, y0, y1, d0, d1, t):
    h = t1 - t0
    s = (t - t0) / h
    h00 = 2 * s ** 3 - 3 * s ** 2 + 1
    h10 = s ** 3 - 2 * s ** 2 + s
    h01 = -2 * s ** 3 + 3 * s ** 2
    h11 = s ** 3 - s ** 2
    return h00 * y0 + h10 * h * d0 + h01 * y1 + h11 * h * d1


def _inv_gamma(v):
    b = v / C_KM_S
    return math.sqrt(1.0 - b * b)


def _table_at_t(tab, t):
    i = _seg_index(tab["t"], tab["n"], t)
    T, X, V, U = tab["t"], tab["x"], tab["v"], tab["tau"]
    x = _hermite(T[i], T[i + 1], X[i], X[i + 1], V[i], V[i + 1], t)
    tau = _hermite(T[i], T[i + 1], U[i], U[i + 1], _inv_gamma(V[i]), _inv_gamma(V[i + 1]), t)
    w = (t - T[i]) / (T[i + 1] - T[i])
    v = V[i] + w * (V[i + 1] - V[i])
    return x, v, tau


def _table_t_from_tau(tab, tau):
    i = _seg_index(tab["tau"], tab["n"], tau)
    lo, hi = tab["t"][i], tab["t"][i + 1]
    for _ in range(MAX_SEARCH_ITER):          # bisection inside one segment (tau(t) monotonic)
        mid = 0.5 * (lo + hi)
        if _table_at_t(tab, mid)[2] < tau:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def timeline(prof, distance_km):
    """Phase boundaries for a straight flight of `distance_km` (Earth time s, proper time s, track km)."""
    D = _finite(distance_km, "distance_km")
    b, m, f = prof["boost"], prof["magsail"], prof["fusion"]
    fixed_x = b["x"][-1] + m["x"][-1] + f["x"][-1]
    if D < fixed_x:
        raise NavError(f"distance {D:.6g} km shorter than the fixed phases ({fixed_x:.6g} km)")
    lc = D - fixed_x
    tc = lc / prof["v_cruise"]
    rows, t0, u0, x0 = [], 0.0, 0.0, 0.0
    for name, dt, du, dx in (("BOOST", b["t"][-1], b["tau"][-1], b["x"][-1]),
                             ("CRUISE", tc, tc / prof["gamma_cruise"], lc),
                             ("MAGSAIL", m["t"][-1], m["tau"][-1], m["x"][-1]),
                             ("FUSION", f["t"][-1], f["tau"][-1], f["x"][-1])):
        rows.append(dict(phase=name, t_start_s=t0, t_end_s=t0 + dt, tau_start_s=u0, tau_end_s=u0 + du,
                         s_start_km=x0, s_end_km=x0 + dx))
        t0, u0, x0 = t0 + dt, u0 + du, x0 + dx
    return rows


def along_track(prof, distance_km, ship_time_s, time_scale="earth"):
    """Phase, distance flown (km), speed (km/s), Earth and proper elapsed time at a ship time."""
    if time_scale not in TIME_SCALES:
        raise NavError(f"time_scale must be one of {TIME_SCALES}")
    tq = _finite(ship_time_s, "ship_time_s")
    rows = timeline(prof, distance_km)
    key0, key1 = ("t_start_s", "t_end_s") if time_scale == "earth" else ("tau_start_s", "tau_end_s")
    if tq < 0.0 or tq > rows[-1][key1]:
        raise NavError(f"ship_time_s {tq} outside flight [0, {rows[-1][key1]}] ({time_scale})")
    k = 3
    for j in range(4):
        if tq < rows[j][key1]:
            k = j
            break
    r = rows[k]
    local = tq - r[key0]
    tabs = {"BOOST": prof["boost"], "MAGSAIL": prof["magsail"], "FUSION": prof["fusion"]}
    if r["phase"] == "CRUISE":
        v = prof["v_cruise"]
        lt = local if time_scale == "earth" else local * prof["gamma_cruise"]
        x, tau = v * lt, lt / prof["gamma_cruise"]
    else:
        tab = tabs[r["phase"]]
        lt = local if time_scale == "earth" else _table_t_from_tau(tab, min(local, tab["tau"][-1]))
        lt = min(lt, tab["t"][-1])
        x, v, tau = _table_at_t(tab, lt)
    return dict(phase=r["phase"], s_km=r["s_start_km"] + x, v_km_s=v, beta=v / C_KM_S,
                gamma=1.0 / _inv_gamma(v), earth_elapsed_s=r["t_start_s"] + lt, proper_elapsed_s=r["tau_start_s"] + tau,
                remaining_km=rows[-1]["s_end_km"] - (r["s_start_km"] + x))


# ----------------------------------------------------------------------------- intercept
def intercept(cat, prof, dest_id, departure_epoch):
    """Intercept aim point: the target's geometric position at the arrival epoch, where the arrival epoch
    itself depends on the flight distance (fixed-point iteration, bounded)."""
    if dest_id not in cat["destinations"]:
        raise NavError(f"unknown destination {dest_id!r}")
    t_dep = _epoch(departure_epoch, "departure_epoch")
    sid = cat["destinations"][dest_id]["star_id"]
    p_dep, vel = star_state(cat, sid, t_dep)
    D = _norm(p_dep)
    converged = False
    it = 0
    for it in range(1, MAX_INTERCEPT_ITER + 1):
        T = timeline(prof, D)[-1]["t_end_s"]
        t_arr = t_dep + T / JYEAR_S
        p_arr, _ = star_state(cat, sid, t_arr)
        D_new = _norm(p_arr)
        if abs(D_new - D) <= INTERCEPT_TOL_KM:
            D = D_new
            converged = True
            break
        D = D_new
    if not converged:
        raise NavError("intercept iteration did not converge")
    rows = timeline(prof, D)
    t_arr = t_dep + rows[-1]["t_end_s"] / JYEAR_S
    p_arr, _ = star_state(cat, sid, t_arr)
    p_obs_dep, _ = star_state(cat, sid, t_dep, light_time=False)   # where the star APPEARS at departure
    u = tuple(p_arr[i] / _norm(p_arr) for i in range(3))
    un = tuple(p_obs_dep[i] / _norm(p_obs_dep) for i in range(3))
    cx = (p_arr[1] * un[2] - p_arr[2] * un[1], p_arr[2] * un[0] - p_arr[0] * un[2], p_arr[0] * un[1] - p_arr[1] * un[0])
    return dict(dest_id=dest_id, star_id=sid, departure_epoch=t_dep, arrival_epoch=t_arr,
                arrival_epoch_proper=t_dep + rows[-1]["tau_end_s"] / JYEAR_S,
                flight_distance_km=D, aim_point_km=p_arr, aim_unit=u, target_velocity_km_s=vel,
                apparent_direction_at_departure=un,
                aim_shift_vs_apparent_arcsec=math.degrees(_angle_rad(u, un)) * 3600.0,
                aim_shift_vs_geometric_departure_arcsec=math.degrees(_angle_rad(u, p_dep)) * 3600.0,
                miss_if_aimed_at_apparent_km=_norm(cx),
                displacement_since_departure_km=_norm([p_arr[i] - p_dep[i] for i in range(3)]),
                light_time_shift_km=_norm([p_dep[i] - p_obs_dep[i] for i in range(3)]),
                delta_v_to_match_target_km_s=_norm(vel), iterations=it, timeline=rows)


# ----------------------------------------------------------------------------- top-level query
def nav_state(cat, prof, dest_id, departure_epoch, ship_time_s, time_scale="proper"):
    """Ship state for a given ship time since departure: phase, position/velocity (barycentric ICRS),
    elapsed Earth/proper time, plus the target state and intercept aim. Deterministic and side-effect free."""
    ic = intercept(cat, prof, dest_id, departure_epoch)
    a = along_track(prof, ic["flight_distance_km"], ship_time_s, time_scale)
    u = ic["aim_unit"]
    epoch_now = ic["departure_epoch"] + a["earth_elapsed_s"] / JYEAR_S
    tpos, tvel = star_state(cat, ic["star_id"], epoch_now)
    pos = tuple(u[i] * a["s_km"] for i in range(3))
    return dict(navref_version=NAVREF_VERSION, catalog_version=cat["version"], dest_id=dest_id,
                phase=a["phase"], epoch_tdb_jyr=epoch_now,
                earth_elapsed_s=a["earth_elapsed_s"], proper_elapsed_s=a["proper_elapsed_s"],
                ship_pos_km=pos, ship_vel_km_s=tuple(u[i] * a["v_km_s"] for i in range(3)),
                beta=a["beta"], gamma=a["gamma"], distance_flown_km=a["s_km"], distance_remaining_km=a["remaining_km"],
                target_pos_km=tpos, target_vel_km_s=tvel, aim_point_km=ic["aim_point_km"], aim_unit=u,
                arrival_epoch=ic["arrival_epoch"], aim_shift_vs_apparent_arcsec=ic["aim_shift_vs_apparent_arcsec"])
