"""navref package. DESIGN AND REFERENCE SOFTWARE - NOT FLIGHT-CERTIFIED."""
from .navref import *  # noqa: F401,F403
from .navref import NAVREF_VERSION, NavError  # noqa: F401
