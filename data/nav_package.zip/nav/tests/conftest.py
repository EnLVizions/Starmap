import os, sys, json, pytest
NAV = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, NAV)
import navref.navref as nr


def _read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def _json(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)

@pytest.fixture(scope="session")
def cat():
    return nr.load_catalog(os.path.join(NAV, "data", "star_catalog.json"))

@pytest.fixture(scope="session")
def prof():
    return nr.load_profile(os.path.join(NAV, "data", "flight_profile.json"))

@pytest.fixture(scope="session")
def raw_cat():
    return _json(os.path.join(NAV, "data", "star_catalog.json"))

@pytest.fixture(scope="session")
def raw_prof():
    return _json(os.path.join(NAV, "data", "flight_profile.json"))
