"""Package-level verification of generated data files."""
import os, json, glob, math
import numpy as np, pytest
import navref.navref as nr
from conftest import NAV, _read, _json
from astropy.time import Time

DEP = _json(os.path.join(NAV, "manifest.json"))["departure_epoch_jyr"]


def parse_oem(path):
    lines = _read(path).splitlines(); segs = []; cur = None; header = {}
    i = 0
    for ln in lines:
        s = ln.strip()
        if not s or s.startswith("COMMENT"): continue
        if s == "META_START": cur = dict(meta={}, data=[]); segs.append(cur); mode = "meta"; continue
        if s == "META_STOP": mode = "data"; continue
        if cur is None: k, v = [x.strip() for x in s.split("=", 1)]; header[k] = v; continue
        if mode == "meta": k, v = [x.strip() for x in s.split("=", 1)]; cur["meta"][k] = v
        else: cur["data"].append(s.split())
    return header, segs


@pytest.mark.parametrize("path", sorted(glob.glob(os.path.join(NAV, "oem", "*.oem"))))
def test_oem_layout_and_values(path, cat, prof):
    """Verifies: NAV-REQ-022"""
    header, segs = parse_oem(path)
    assert header["CCSDS_OEM_VERS"] in ("2.0", "3.0") and "CREATION_DATE" in header and "ORIGINATOR" in header
    did = os.path.basename(path)[:-4]; last = None
    for sg in segs:
        for k in ("OBJECT_NAME", "OBJECT_ID", "CENTER_NAME", "REF_FRAME", "TIME_SYSTEM", "START_TIME", "STOP_TIME"):
            assert k in sg["meta"]
        assert sg["meta"]["TIME_SYSTEM"] == "TDB" and sg["meta"]["REF_FRAME"] == "ICRF"
        for row in sg["data"]:
            assert len(row) == 7
            t = Time(row[0], scale="tdb").jyear
            assert last is None or t >= last - 1e-9; last = t
        for row in sg["data"][::7]:
            t = Time(row[0], scale="tdb").jyear
            p = [float(x) for x in row[1:4]]; v = [float(x) for x in row[4:7]]
            T = nr.timeline(prof, nr.intercept(cat, prof, did, DEP)["flight_distance_km"])[-1]["t_end_s"]
            ok = False
            for dt in (-1e-3, 0.0, 1e-3):   # epochs are written to 1 ms; at phase boundaries accept either side
                te = min(max((t - DEP) * nr.JYEAR_S + dt, 0.0), T)
                s = nr.nav_state(cat, prof, did, DEP, te, "earth")
                # ms epoch rounding x 0.23c = 69 km along track at most
                ok = ok or (math.dist(p, s["ship_pos_km"]) < 1.0 + 70.0 and math.dist(v, s["ship_vel_km_s"]) < 1e-6 * 7e4 + 1e-3)
            assert ok, row


def test_catalog_consistency(raw_cat):
    """Verifies: NAV-REQ-023"""
    for s in raw_cat["stars"]:
        p, v = nr.astrometric_to_cartesian(s["ra_deg"], s["dec_deg"], s["parallax_mas"], s["pmra_mas_yr"] or 0.0, s["pmdec_mas_yr"] or 0.0, s["rv_km_s"])
        assert math.dist(p, s["pos_km"]) / math.sqrt(sum(x * x for x in p)) < 1e-9
        assert (v is None) == (s["vel_km_s"] is None)
        if v is not None: assert math.dist(v, s["vel_km_s"]) < 1e-9


def test_manifest_checksums():
    """Verifies: NAV-REQ-023, NAV-REQ-002"""
    m = _json(os.path.join(NAV, "manifest.json"))
    assert len(m["files"]) > 20
    for f, h in m["files"].items():
        assert nr.sha256_file(os.path.join(NAV, f)) == h, f


def test_notice_in_outputs():
    """Verifies: NAV-REQ-024"""
    for f in glob.glob(os.path.join(NAV, "data", "*.json")) + glob.glob(os.path.join(NAV, "trajectories", "*.json")) + glob.glob(os.path.join(NAV, "oem", "*.oem")):
        assert "NOT FLIGHT-CERTIFIED" in _read(f), f
    m = _json(os.path.join(NAV, "manifest.json")); assert "NOT FLIGHT-CERTIFIED" in m["notice"]
