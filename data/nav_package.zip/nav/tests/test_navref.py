"""Unit tests for navref. Each test names the requirement(s) it verifies in a 'Verifies:' line."""
import os, copy, json, math, ast, hashlib
import numpy as np, pytest
import navref.navref as nr
from conftest import NAV, _read, _json

LY = nr.LY_KM; YR = nr.JYEAR_S; DEP = 2032.0


def test_format_rejected(raw_cat, raw_prof):
    """Verifies: NAV-REQ-001"""
    c = copy.deepcopy(raw_cat); c["format"] = "pythagoras-nav-catalog-0.9"
    with pytest.raises(nr.NavError): nr.validate_catalog(c)
    p = copy.deepcopy(raw_prof); p["format"] = "x"
    with pytest.raises(nr.NavError): nr.validate_profile(p)
    with pytest.raises(nr.NavError): nr.validate_catalog([])


def test_checksum(tmp_path, raw_prof):
    """Verifies: NAV-REQ-002"""
    f = tmp_path / "p.json"; f.write_text(json.dumps(raw_prof))
    good = hashlib.sha256(f.read_bytes()).hexdigest()
    assert nr.load_profile(str(f), good)["format"] == nr.PROFILE_FORMAT
    with pytest.raises(nr.NavError): nr.load_profile(str(f), "0" * 64)
    g = tmp_path / "c.json"; g.write_text(_read(os.path.join(NAV, "data", "star_catalog.json")))
    with pytest.raises(nr.NavError): nr.load_catalog(str(g), "0" * 64)
    assert nr.load_catalog(str(g), nr.sha256_file(str(g)))["format"] == nr.CATALOG_FORMAT


@pytest.mark.parametrize("bad", [float("nan"), float("inf"), -float("inf"), True, "2032", None, [2032]])
def test_non_finite_inputs(cat, prof, bad):
    """Verifies: NAV-REQ-003"""
    with pytest.raises(nr.NavError): nr.intercept(cat, prof, "proxima-centauri", bad)
    with pytest.raises(nr.NavError): nr.nav_state(cat, prof, "proxima-centauri", DEP, bad)
    with pytest.raises(nr.NavError): nr.astrometric_to_cartesian(bad, 0, 100, 0, 0, 0)
    with pytest.raises(nr.NavError): nr.along_track(prof, bad, 0.0)


def test_bad_astrometry(cat):
    """Verifies: NAV-REQ-003"""
    with pytest.raises(nr.NavError): nr.astrometric_to_cartesian(10, 0, 0.0, 0, 0, 0)
    with pytest.raises(nr.NavError): nr.astrometric_to_cartesian(10, 0, -5.0, 0, 0, 0)
    with pytest.raises(nr.NavError): nr.astrometric_to_cartesian(10, 95, 5.0, 0, 0, 0)


def test_bad_data_rows(raw_cat, raw_prof):
    """Verifies: NAV-REQ-003, NAV-REQ-001"""
    cases = []
    c = copy.deepcopy(raw_cat); c["stars"][0]["pos_km"] = [1, 2]; cases.append(c)
    c = copy.deepcopy(raw_cat); c["stars"][1]["id"] = c["stars"][0]["id"]; cases.append(c)
    c = copy.deepcopy(raw_cat); c["stars"][0]["pos_km"] = [0, 0, 0]; cases.append(c)
    c = copy.deepcopy(raw_cat); c["stars"][0]["ref_epoch"] = 1800.0; cases.append(c)
    c = copy.deepcopy(raw_cat); c["stars"] = []; cases.append(c)
    c = copy.deepcopy(raw_cat); c["destinations"] = []; cases.append(c)
    c = copy.deepcopy(raw_cat); c["destinations"][0]["star_id"] = "nope"; cases.append(c)
    c = copy.deepcopy(raw_cat); sid = c["destinations"][0]["star_id"]
    next(s for s in c["stars"] if s["id"] == sid)["vel_km_s"] = None; cases.append(c)
    c = copy.deepcopy(raw_cat); c["stars"][0]["vel_km_s"] = [1, float("nan"), 2]; cases.append(c)
    for c in cases:
        with pytest.raises(nr.NavError): nr.validate_catalog(c)
    pc = []
    p = copy.deepcopy(raw_prof); p["phases"] = p["phases"][:2]; pc.append(p)
    p = copy.deepcopy(raw_prof); p["phases"][0]["t_s"][5] = p["phases"][0]["t_s"][4]; pc.append(p)
    p = copy.deepcopy(raw_prof); p["phases"][1]["v_km_s"][3] = 4e5; pc.append(p)
    p = copy.deepcopy(raw_prof); p["phases"][2]["tau_s"] = p["phases"][2]["tau_s"][:-1]; pc.append(p)
    p = copy.deepcopy(raw_prof); p["phases"][0]["t_s"][0] = 1.0; pc.append(p)
    p = copy.deepcopy(raw_prof); p["cruise"]["v_km_s"] = 3.1e5; pc.append(p)
    p = copy.deepcopy(raw_prof); p["phases"][0]["x_km"] = "abc"; pc.append(p)
    for p in pc:
        with pytest.raises(nr.NavError): nr.validate_profile(p)


@pytest.mark.parametrize("ep", [2015.99, 3000.01, 1e9])
def test_epoch_range(cat, prof, ep):
    """Verifies: NAV-REQ-004"""
    with pytest.raises(nr.NavError): nr.star_state(cat, "proxima-centauri", ep)
    with pytest.raises(nr.NavError): nr.intercept(cat, prof, "proxima-centauri", ep)


def test_epoch_range_arrival_beyond_limit(cat, prof):
    """Verifies: NAV-REQ-004"""
    with pytest.raises(nr.NavError): nr.intercept(cat, prof, "proxima-centauri", 2990.0)


def test_unknown_ids(cat, prof):
    """Verifies: NAV-REQ-005"""
    with pytest.raises(nr.NavError): nr.intercept(cat, prof, "vulcan", DEP)
    with pytest.raises(nr.NavError): nr.star_state(cat, "vulcan", DEP)
    with pytest.raises(nr.NavError): nr.along_track(prof, 5 * LY, 0.0, "ship-clock")


def test_astrometry_vs_astropy(raw_cat):
    """Verifies: NAV-REQ-006"""
    import astropy.units as u
    from astropy.coordinates import SkyCoord
    n = 0
    for s in raw_cat["stars"]:
        if s["rv_km_s"] is None: continue
        c = SkyCoord(ra=s["ra_deg"] * u.deg, dec=s["dec_deg"] * u.deg, distance=(1000 / s["parallax_mas"]) * u.pc,
                     pm_ra_cosdec=s["pmra_mas_yr"] * u.mas / u.yr, pm_dec=s["pmdec_mas_yr"] * u.mas / u.yr,
                     radial_velocity=s["rv_km_s"] * u.km / u.s, frame="icrs")
        p, v = nr.astrometric_to_cartesian(s["ra_deg"], s["dec_deg"], s["parallax_mas"], s["pmra_mas_yr"], s["pmdec_mas_yr"], s["rv_km_s"])
        P = c.cartesian.xyz.to(u.km).value; V = c.velocity.d_xyz.to(u.km / u.s).value
        assert np.linalg.norm(np.array(p) - P) / np.linalg.norm(P) < 1e-9
        assert np.linalg.norm(np.array(v) - V) < 1e-6
        n += 1
        if n >= 300: break
    assert n >= 300


def test_missing_rv(cat):
    """Verifies: NAV-REQ-007"""
    p, v = nr.astrometric_to_cartesian(10.0, 20.0, 100.0, 5.0, 5.0, None)
    assert v is None and p is not None
    sid = next(k for k, s in cat["stars"].items() if s["vel_km_s"] is None)
    with pytest.raises(nr.NavError): nr.star_state(cat, sid, DEP)


def test_linear_propagation(cat):
    """Verifies: NAV-REQ-008"""
    s = cat["stars"]["proxima-centauri"]
    p0, v0 = nr.star_state(cat, "proxima-centauri", s["ref_epoch"], light_time=False)
    assert p0 == s["pos_km"] and v0 == s["vel_km_s"]
    p1, _ = nr.star_state(cat, "proxima-centauri", 2100.0, light_time=False)
    dt = (2100.0 - s["ref_epoch"]) * YR
    assert max(abs(p1[i] - (s["pos_km"][i] + s["vel_km_s"][i] * dt)) for i in range(3)) < 1e-3


def test_light_time(cat):
    """Verifies: NAV-REQ-009"""
    a, v = nr.star_state(cat, "proxima-centauri", DEP, light_time=False)
    b, _ = nr.star_state(cat, "proxima-centauri", DEP, light_time=True)
    d = math.sqrt(sum(x * x for x in a)) / nr.C_KM_S
    assert max(abs(b[i] - a[i] - v[i] * d) for i in range(3)) < 1e-2   # float64 at 4e13 km ~ 1e-2 km
    assert 20 < math.dist(a, b) / nr.AU_KM < 40          # ~29 AU for Proxima
    c, _ = nr.star_state(cat, "proxima-centauri", DEP)    # default = catalogue flag (True)
    assert c == b


def test_profile_vs_design(prof):
    """Verifies: NAV-REQ-010"""
    tl = nr.timeline(prof, 4.24 * 9.4607e12)          # design doc uses ly = 9.4607e15 m
    assert abs(tl[-1]["t_end_s"] / YR - 33.47073361793949) < 0.01
    assert abs(tl[-1]["tau_end_s"] / YR - 33.09422248721085) < 0.01
    d = {r["phase"]: r for r in tl}
    assert abs((d["BOOST"]["t_end_s"] - d["BOOST"]["t_start_s"]) / YR - 2.923542981722311) < 1e-9
    assert abs((d["MAGSAIL"]["t_end_s"] - d["MAGSAIL"]["t_start_s"]) / YR - 22.516529677291746) < 1e-9
    assert abs((d["FUSION"]["t_end_s"] - d["FUSION"]["t_start_s"]) / YR - 1.9378177614609784) < 1e-9


def test_interpolation_vs_fullres(prof):
    """Verifies: NAV-REQ-011"""
    f = np.load(os.path.join(NAV, "tests", "fixtures", "profile_fullres.npz"))
    for k in ("boost", "magsail"):
        T, X, V, U = f[k]
        for i in range(0, len(T), 3):
            x, v, u = nr._table_at_t(prof[k], float(T[i]))
            assert abs(x - X[i]) < 5e5 and abs(v - V[i]) < 0.1 and abs(u - U[i]) < 1.0


def test_phase_labels(prof):
    """Verifies: NAV-REQ-012"""
    D = 10 * LY; tl = nr.timeline(prof, D)
    for r in tl:
        assert nr.along_track(prof, D, r["t_start_s"], "earth")["phase"] == r["phase"]
        mid = 0.5 * (r["t_start_s"] + r["t_end_s"])
        assert nr.along_track(prof, D, mid, "earth")["phase"] == r["phase"]
        assert nr.along_track(prof, D, 0.5 * (r["tau_start_s"] + r["tau_end_s"]), "proper")["phase"] == r["phase"]
    assert nr.along_track(prof, D, tl[-1]["t_end_s"], "earth")["phase"] == "FUSION"
    assert nr.along_track(prof, D, tl[-1]["tau_end_s"], "proper")["phase"] == "FUSION"
    assert [r["phase"] for r in tl] == ["BOOST", "CRUISE", "MAGSAIL", "FUSION"]


def test_time_scale_roundtrip(prof):
    """Verifies: NAV-REQ-013"""
    D = 4.24 * LY; tl = nr.timeline(prof, D)
    for t in np.linspace(0, tl[-1]["tau_end_s"], 499):
        a = nr.along_track(prof, D, float(t), "proper")
        b = nr.along_track(prof, D, a["earth_elapsed_s"], "earth")
        assert abs(b["proper_elapsed_s"] - t) < 1e-3
        assert a["phase"] == b["phase"] or abs(b["proper_elapsed_s"] - t) < 1e-3


def test_monotonic_continuous(prof):
    """Verifies: NAV-REQ-014"""
    D = 12 * LY; tl = nr.timeline(prof, D); last = -1.0
    for t in np.linspace(0, tl[-1]["t_end_s"], 3001):
        s = nr.along_track(prof, D, float(t), "earth")["s_km"]; assert s >= last - 1e-6; last = s
    for r in tl[:-1]:
        e = r["t_end_s"]
        a = nr.along_track(prof, D, e * (1 - 1e-12), "earth")["v_km_s"]; b = nr.along_track(prof, D, e, "earth")["v_km_s"]
        assert abs(a - b) < 10.0   # design-code discretisation: boost overshoot 8.2 km/s, magsail end 0.45 km/s (REQ-014)


def test_time_out_of_range(prof):
    """Verifies: NAV-REQ-015"""
    D = 8 * LY; tl = nr.timeline(prof, D)
    for t, sc in ((-1.0, "earth"), (tl[-1]["t_end_s"] + 1.0, "earth"), (-1e-9, "proper"), (tl[-1]["tau_end_s"] + 1.0, "proper")):
        with pytest.raises(nr.NavError): nr.along_track(prof, D, t, sc)


def test_intercept_consistency(cat, prof):
    """Verifies: NAV-REQ-016"""
    for did in cat["destinations"]:
        ic = nr.intercept(cat, prof, did, DEP)
        assert ic["iterations"] <= nr.MAX_INTERCEPT_ITER
        assert abs(math.sqrt(sum(x * x for x in ic["aim_point_km"])) - ic["flight_distance_km"]) < 1.0
        p, _ = nr.star_state(cat, ic["star_id"], ic["arrival_epoch"])
        assert math.dist(p, ic["aim_point_km"]) < 1.0


def test_intercept_nonconvergence(cat, prof, monkeypatch):
    """Verifies: NAV-REQ-016"""
    monkeypatch.setattr(nr, "MAX_INTERCEPT_ITER", 1)
    with pytest.raises(nr.NavError): nr.intercept(cat, prof, "teegarden-s-star", DEP)


def test_intercept_independent_solver(cat, prof):
    """Verifies: NAV-REQ-017"""
    tl0 = nr.timeline(prof, 5 * LY); fixed_t = tl0[-1]["t_end_s"] - tl0[1]["t_end_s"] + tl0[1]["t_start_s"]
    fixed_x = tl0[-1]["s_end_km"] - (tl0[1]["s_end_km"] - tl0[1]["s_start_km"]); vc = prof["v_cruise"]
    for did, d in cat["destinations"].items():
        s = cat["stars"][d["star_id"]]; p0 = np.array(s["pos_km"]); v = np.array(s["vel_km_s"])
        def f(T):  # residual: flight time implied by distance to the geometric target at t_dep+T, minus T
            r = p0 + v * ((DEP - s["ref_epoch"]) * YR + T); r = r + v * np.linalg.norm(r) / nr.C_KM_S
            return fixed_t + (np.linalg.norm(r) - fixed_x) / vc - T
        lo, hi = 1.0 * YR, 500.0 * YR
        for _ in range(200):
            mid = 0.5 * (lo + hi)
            if f(lo) * f(mid) <= 0: hi = mid
            else: lo = mid
        ic = nr.intercept(cat, prof, did, DEP)
        assert abs((ic["arrival_epoch"] - DEP) * YR - 0.5 * (lo + hi)) < 1.0


def test_determinism(cat, prof):
    """Verifies: NAV-REQ-018"""
    a = nr.nav_state(cat, prof, "ross-128", 2040.5, 1.234e9, "proper")
    b = nr.nav_state(cat, prof, "ross-128", 2040.5, 1.234e9, "proper")
    assert repr(a) == repr(b)
    src = _read(nr.__file__)
    for word in ("import random", "random.", "import time", "datetime", "os.environ", "getenv", "import os"):
        assert word not in src


REQUIRED = {"navref_version", "catalog_version", "dest_id", "phase", "epoch_tdb_jyr", "earth_elapsed_s", "proper_elapsed_s", "ship_pos_km",
            "ship_vel_km_s", "beta", "gamma", "distance_flown_km", "distance_remaining_km", "target_pos_km", "target_vel_km_s",
            "aim_point_km", "aim_unit", "arrival_epoch", "aim_shift_vs_apparent_arcsec"}


def test_nav_state_fields(cat, prof):
    """Verifies: NAV-REQ-019"""
    for t in (0.0, 1e8, 5e8, 9e8):
        s = nr.nav_state(cat, prof, "proxima-centauri", DEP, t, "earth")
        assert REQUIRED <= set(s)
        assert max(abs(s["ship_pos_km"][i] - s["aim_unit"][i] * s["distance_flown_km"]) for i in range(3)) < 1e-6
        assert 0 <= s["beta"] < 0.2301 and s["gamma"] >= 1.0


def test_distance_too_short(prof):
    """Verifies: NAV-REQ-020"""
    with pytest.raises(nr.NavError): nr.timeline(prof, 1.0 * LY)


FORBIDDEN_CALLS = {"eval", "exec", "compile", "__import__", "input"}
ALLOWED_IMPORTS = {"json", "math", "hashlib"}


def check_coding_rules(path):
    tree = ast.parse(_read(path)); problems = []
    for node in ast.walk(tree):
        if isinstance(node, ast.While): problems.append(f"while loop at line {node.lineno}")
        if isinstance(node, ast.Global): problems.append(f"global at line {node.lineno}")
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            names = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module]
            problems += [f"import {n} at line {node.lineno}" for n in names if n not in ALLOWED_IMPORTS]
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in FORBIDDEN_CALLS:
            problems.append(f"{node.func.id}() at line {node.lineno}")
        if isinstance(node, ast.For):
            it = node.iter
            ok = isinstance(it, ast.Call) and isinstance(it.func, ast.Name) and it.func.id == "range"
            ok = ok or isinstance(it, (ast.Tuple, ast.List))
            if not ok: problems.append(f"for loop over non-range iterable at line {node.lineno}")
    for fn in [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]:
        for c in ast.walk(fn):
            if isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id == fn.name:
                problems.append(f"recursion in {fn.name}")
    return problems


def test_coding_rules():
    """Verifies: NAV-REQ-021"""
    assert check_coding_rules(nr.__file__) == []


def test_coding_rules_checker_detects(tmp_path):
    """Verifies: NAV-REQ-021"""
    f = tmp_path / "bad.py"
    f.write_text("import os\ndef f(n):\n    global X\n    while n:\n        n -= 1\n    for k in n: pass\n    eval('1')\n    return f(n)\n")
    p = check_coding_rules(str(f))
    assert len(p) == 6


def test_notice():
    """Verifies: NAV-REQ-024"""
    assert "NOT FLIGHT-CERTIFIED" in _read(nr.__file__)


def test_loop_bounds_enforced(tmp_path, prof, monkeypatch):
    """Verifies: NAV-REQ-021, NAV-REQ-003"""
    f = tmp_path / "big.bin"; f.write_bytes(b"0" * (3 << 20))
    monkeypatch.setattr(nr, "MAX_HASH_CHUNKS", 2)
    with pytest.raises(nr.NavError): nr.sha256_file(str(f))
    monkeypatch.setattr(nr, "MAX_SEARCH_ITER", 1)
    with pytest.raises(nr.NavError): nr._seg_index(prof["magsail"]["t"], prof["magsail"]["n"], 1e8)
