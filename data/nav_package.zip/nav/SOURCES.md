# Sources and credits: Pythagoras navigation package

**Upstream:** the star-map v2 and v1.2 builds (`../SOURCES.md`). They cover the SIMBAD/Gaia cross-match, system grouping, destination selection, ranks and LISM look-ups, with all of their credits.

## New archive queries for this package (raw files and `_meta.json` in `raw/`)

| Source | Institution / country | Used for | Query | Retrieved (UTC) |
|---|---|---|---|---|
| **ESA Gaia DR3** `gaiadr3.gaia_source` | ESA / Gaia DPAC, Europe (archive at ESAC, Spain) | Astrometry at epoch 2016.0 with errors and correlations (ra, dec, parallax, pmra, pmdec, RV, RUWE) | `https://gea.esac.esa.int/tap-server/tap/sync`, `parallax > 63.33` (same cut as star map v2) | 2026-10-17T17:29:45Z, 1268 rows |
| **SIMBAD** `basic` | CDS, Université de Strasbourg / CNRS, France | Coordinates (J2000), parallax, proper motions with error ellipse, RV with errors and bibcodes, for objects where Gaia DR3 is not the astrometric source (e.g. α Cen A/B, bright stars) | `https://simbad.cds.unistra.fr/simbad/sim-tap/sync`, `plx_value > 63.33` | 2026-10-17T17:30:14Z, 1912 rows |
| **Hipparcos, new reduction** (van Leeuwen 2007, A&A 474, 653), VizieR `I/311/hip2` | ESA, Europe; served by CDS VizieR, France | Guide stars and the sky-view background (Hp < 6.0): positions (J1991.25), parallax, proper motions, errors, B−V, solution type | `https://vizier.cds.unistra.fr/viz-bin/asu-tsv?-source=I/311/hip2&...&Hpmag=<6.0` | 2026-10-17T17:29:50Z, 4561 rows |
| **SIMBAD** `ident` / `basic` | CDS, France | Names and spectral types for Hipparcos stars with Hp < 4.0 | TAP, identifier list | 2026-10-17T17:35:02Z, 498 rows |

## Models, formulas and documents

- **Flight profile:** Pythagoras Concept Design v2.4 §4.7 and its code (`/workspace/starship-design/calc_faststop.py`, `calc_shield_sail.py`, `calc_prototype.py`). It is MC²🍄's project document, and all of it is marked [SPECULATIVE].
- **Local ISM clouds:** Redfield & Linsky 2008, ApJ 673, 283, via the Kinematic Calculator (Wesleyan University / CU Boulder, USA), as used in the star map.
- **ICRS → Cartesian:** standard astrometric relations. They were checked in tests against **astropy** (The Astropy Collaboration; BSD licence).
- **Constants:**
  - IAU 2012 au (149597870.7 km)
  - SI c (299792.458 km/s)
  - Julian year (365.25 d)
  - proton rest energy 938.27208816 MeV (CODATA 2018)
- **Relativistic aberration and Doppler:** standard special-relativity formulas, cos θ' = (cos θ + β)/(1 + β cos θ) and δ = γ(1 + β cos θ).
- **B−V → temperature:** Ballesteros, F. J. 2012, EPL 97, 34.
- **Black-body colour:** CIE 1931 2° colour-matching functions via the analytic multi-lobe fit of Wyman, Sloan & Shirley 2013, Journal of Computer Graphics Techniques 2(2), 1. Converted with the sRGB (IEC 61966-2-1) matrix and gamma.
- **CCSDS 502.0-B-3:** Orbit Data Messages (OEM layout followed; files not validated by a CCSDS tool). Consultative Committee for Space Data Systems (international).
- **Certification references, mapped and not complied with:**
  - NASA NPR 7150.2D, Software Engineering Requirements (nodis3.gsfc.nasa.gov) and the NASA Software Engineering Handbook (swehb.nasa.gov)
  - RTCA DO-178C, via secondary summaries; the standard itself was not consulted
  - Holzmann 2006, "The Power of Ten", IEEE Computer 39(6)
- **Software:**
  - three.js r147 (MIT licence; inlined in `sim.html`) with OrbitControls
  - Python, NumPy, pandas, astropy, pytest, coverage.py
  - headless Google Chrome for the screenshots

Every number in the outputs is computed from the sources above. Where data are missing (RV, names, LISM distances, dust), the files say "unknown" or leave the field empty rather than filling it in.
