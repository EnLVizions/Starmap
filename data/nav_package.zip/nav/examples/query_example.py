"""Example: load the nav package and query the state 10 years (ship proper time) after departure.
DESIGN AND REFERENCE SOFTWARE - NOT FLIGHT-CERTIFIED."""
import os, sys, json
NAV = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, NAV)
import navref
man = json.load(open(os.path.join(NAV, "manifest.json")))
cat = navref.load_catalog(os.path.join(NAV, "data/star_catalog.json"), man["files"]["data/star_catalog.json"])
prof = navref.load_profile(os.path.join(NAV, "data/flight_profile.json"), man["files"]["data/flight_profile.json"])
dep = float(sys.argv[1]) if len(sys.argv) > 1 else man["departure_epoch_jyr"]
s = navref.nav_state(cat, prof, "proxima-centauri", dep, 10 * navref.JYEAR_S, "proper")
print(f"phase {s['phase']}, epoch J{s['epoch_tdb_jyr']:.4f}, beta {s['beta']:.5f}, flown {s['distance_flown_km']/navref.LY_KM:.4f} ly,"
      f" arrival J{s['arrival_epoch']:.4f}, aim shift {s['aim_shift_vs_apparent_arcsec']:.1f} arcsec")
