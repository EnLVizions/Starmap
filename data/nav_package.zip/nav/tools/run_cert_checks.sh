#!/usr/bin/env bash
# Re-run the certification-track evidence: unit tests + statement/branch coverage + traceability matrix.
set -euo pipefail
cd "$(dirname "$0")/.."
PY=../.venv/bin/python
$PY -W error -m pytest -q -p no:cacheprovider --cov=navref --cov-branch --cov-report=term-missing --cov-report=json:cert/coverage.json --junitxml=cert/test_results.xml tests
$PY tools/gen_trace.py
