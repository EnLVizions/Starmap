"""Assemble the self-contained offline simulator sim.html (three.js r147 + OrbitControls inlined, MIT licence) and render PNGs."""
import os, subprocess
NAV = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); SM = os.path.dirname(NAV)
t = open(os.path.join(NAV, "tools/sim_template.html")).read()
t = t.replace("/*THREE*/", open(os.path.join(SM, "vendor/three.min.js")).read()).replace("/*ORBIT*/", open(os.path.join(SM, "vendor/OrbitControls.js")).read())
t = t.replace("/*DATA*/", open(os.path.join(NAV, "sim_data.js")).read())
open(os.path.join(NAV, "sim.html"), "w").write(t)
print("sim.html", len(t) // 1024, "KB")
for name, h in (("sim.png", "dest=proxima-centauri&t=20&sky=1&fov=100"), ("sim_sky_teegarden.png", "dest=teegarden-s-star&t=30&sky=1&fov=150")):
    subprocess.run(["google-chrome", "--headless=new", "--no-sandbox", "--disable-gpu", "--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader",
                    "--window-size=1600,1000", "--virtual-time-budget=4000", f"--screenshot={os.path.join(NAV, name)}", f"file://{NAV}/sim.html#{h}"], check=True, capture_output=True)
    print(name)
