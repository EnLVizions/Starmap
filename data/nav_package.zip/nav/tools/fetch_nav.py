"""Fetch extra astrometry needed by the nav package (read-only public archive queries).
Writes nav/raw/<name>.csv|tsv + <name>_meta.json (endpoint, query, UTC time, rows)."""
import subprocess, json, datetime, os, sys, urllib.parse
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "raw")
PLX_MIN = 63.33   # same parallax cut as star map v2 (50 ly, 3% margin)
Q = {
 "gaia_dr3_astrometry": ("https://gea.esac.esa.int/tap-server/tap/sync", "adql",
   f"SELECT source_id, ref_epoch, ra, dec, ra_error, dec_error, parallax, parallax_error, pmra, pmra_error, pmdec, pmdec_error, "
   f"ra_dec_corr, ra_parallax_corr, ra_pmra_corr, ra_pmdec_corr, dec_parallax_corr, dec_pmra_corr, dec_pmdec_corr, parallax_pmra_corr, "
   f"parallax_pmdec_corr, pmra_pmdec_corr, radial_velocity, radial_velocity_error, ruwe, phot_g_mean_mag, bp_rp "
   f"FROM gaiadr3.gaia_source WHERE parallax > {PLX_MIN} ORDER BY parallax DESC"),
 "simbad_astrometry": ("https://simbad.cds.unistra.fr/simbad/sim-tap/sync", "adql",
   f"SELECT b.oid, b.main_id, b.ra, b.dec, b.coo_err_maj, b.coo_err_min, b.coo_bibcode, b.plx_value, b.plx_err, b.plx_bibcode, "
   f"b.pmra, b.pmdec, b.pm_err_maj, b.pm_err_min, b.pm_err_angle, b.pm_bibcode, b.rvz_radvel, b.rvz_err, b.rvz_bibcode, b.rvz_type "
   f"FROM basic AS b WHERE b.plx_value > {PLX_MIN} ORDER BY plx_value DESC"),
}
VIZ = {"hipparcos_2007_bright": "https://vizier.cds.unistra.fr/viz-bin/asu-tsv?-source=I/311/hip2&-out=HIP,RArad,DErad,Plx,e_Plx,pmRA,e_pmRA,pmDE,e_pmDE,e_RArad,e_DErad,Hpmag,B-V,Sn&Hpmag=%3C6.0&-out.max=unlimited",
       "hipparcos_2007_bright_ids": None}
def run(name, url, data=None):
    for k in range(4):
        cmd = ["curl", "-sS", "--max-time", "600", "-o", os.path.join(OUT, name), "-w", "%{http_code}", url]
        if data: cmd[1:1] = ["--data-urlencode", "REQUEST=doQuery", "--data-urlencode", "LANG=ADQL", "--data-urlencode", "FORMAT=csv", "--data-urlencode", "QUERY=" + data]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.stdout.strip() == "200": return True
        print(name, "attempt", k + 1, "failed", r.stdout, r.stderr[:200])
    return False
def meta(name, endpoint, query, fn):
    n = sum(1 for l in open(os.path.join(OUT, fn)) if l.strip() and not l.startswith("#")) - 1
    json.dump(dict(name=name, endpoint=endpoint, query=query, retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"), rows=n),
              open(os.path.join(OUT, name + "_meta.json"), "w"), indent=1)
    print(name, n)
only = set(sys.argv[1:])
for n, (ep, _, q) in Q.items():
    if only and n not in only: continue
    if run(n + ".csv", ep, q): meta(n, ep, q, n + ".csv")
n = "hipparcos_2007_bright"
if not only or n in only:
    if run(n + ".tsv", VIZ[n]): meta(n, VIZ[n].split("?")[0], VIZ[n].split("?")[1], n + ".tsv")
# ---- names for bright Hipparcos stars (Hp < 4.0), used to label guide stars
n = "simbad_hip_names"
if not only or n in only:
    hips = []
    for line in open(os.path.join(OUT, "hipparcos_2007_bright.tsv")):
        p = line.rstrip("\n").split("\t")
        if len(p) > 12 and p[0].strip().isdigit() and p[11].strip() and float(p[11]) < 4.0: hips.append(int(p[0]))
    q = ("SELECT i.id AS hip_id, b.main_id, b.sp_type, n.id AS name_id FROM ident AS i JOIN basic AS b ON b.oid=i.oidref "
         "LEFT JOIN ident AS n ON n.oidref=b.oid AND n.id LIKE 'NAME %' WHERE i.id IN (" + ",".join(f"'HIP {h}'" for h in hips) + ")")
    ep = "https://simbad.cds.unistra.fr/simbad/sim-tap/sync"
    if run(n + ".csv", ep, q): meta(n, ep, f"[{len(hips)} HIP ids with Hp<4.0] " + q[:220] + " ...", n + ".csv")
