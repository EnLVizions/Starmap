"""Extract the distance-independent flight phases of the Pythagoras Concept Design v2.4 §4.7 profile
(20 kt ship, fusion propellant carried, as in numbers_prototype.json 'prop20') as time-series tables.

Every number comes from the design-document code in /workspace/starship-design:
  * laser boost : calc_faststop.laser_leg (constant beam power, F=(2P/c)(1-b)/(1+b), a0 = 0.1 g, dt = 2e4 s);
                  re-run here step by step to record the series (same algorithm, same step).
  * magsail     : calc_shield_sail.magsail(3000 km, m_ship = 20 kt + D-3He propellant, b0=0.23, bf=0.02,
                  struct=(8e9,1500)), n_i = 0.1 cm^-3 (its default), exactly as calc_prototype.prop_run(2e7).
  * fusion brake: calc_faststop.rocket_leg(0.02, 0.01): constant proper deceleration 0.01 g (hyperbolic motion).
Units out: seconds and km (converted with the design code's own constants: yr = 3.15576e7 s, ly = 9.4607e15 m).
"""
import sys, json, math, os, hashlib
import numpy as np
SD = "/workspace/starship-design"; sys.path.insert(0, SD)
import calc_faststop as fs, calc_shield_sail as cs
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "flight_profile.json")
c, g, yr, ly = fs.c, fs.g, fs.yr, fs.ly
KEEP = 10  # keep every 10th integration step (Hermite interpolation in the nav module; error checked in tests)

def laser_series(beta=0.23, a0_g=0.1, dt=2e4):
    a0 = a0_g * g; u = 0.0; t = 0; x = 0; tau = 0; b = 0
    T = [0.0]; X = [0.0]; V = [0.0]; TAU = [0.0]
    while b < beta:                       # identical loop to calc_faststop.laser_leg
        f = a0 * (1 - b) / (1 + b); u += f * dt / c; b = u / np.sqrt(1 + u * u)
        t += dt; x += b * c * dt; tau += dt * np.sqrt(1 - b * b)
        T.append(t); X.append(x); V.append(b * c); TAU.append(tau)
    return np.array(T), np.array(X), np.array(V), np.array(TAU)

def magsail_series():
    mf = 2e7; pr = (fs.MR(np.arctanh(0.02), 0.05) - 1) * mf; mm = mf + pr
    d = cs.magsail(3000, m_ship=mm, b0=0.23, bf=0.02, struct=(8e9, 1500))
    ts, vs = d["ts"], d["vs"]; dt = np.diff(ts)
    X = np.concatenate([[0.0], np.cumsum(vs[:-1] * dt)])            # x += v*dt with v before update (as in magsail())
    bm = 0.5 * (vs[1:] + vs[:-1]) / c
    TAU = np.concatenate([[0.0], np.cumsum(dt * np.sqrt(1 - bm ** 2))])   # midpoint rule, as calc_faststop.mag
    return ts, X, vs, TAU, d, mm

def fusion_series(b0=0.02, a_g=0.01, n=400):
    a = a_g * g; eta0 = np.arctanh(b0); tau_tot = c * eta0 / a
    tau = np.linspace(0, tau_tot, n + 1); eta = eta0 - a * tau / c
    t = c / a * (np.sinh(eta0) - np.sinh(eta)); x = c ** 2 / a * (np.cosh(eta0) - np.cosh(eta)); v = c * np.tanh(eta)
    return t, x, v, tau

def thin(*arrs):
    idx = list(range(0, len(arrs[0]), KEEP))
    if idx[-1] != len(arrs[0]) - 1: idx.append(len(arrs[0]) - 1)
    return [a[idx] for a in arrs]

phases = []
Tb, Xb, Vb, TAUb = laser_series()
chk = fs.laser_leg(0.23)
assert abs(Tb[-1] / yr - chk["t"]) < 1e-12 and abs(Xb[-1] / ly - chk["x"]) < 1e-12
Tm, Xm, Vm, TAUm, md, mm = magsail_series()
Tf, Xf, Vf, TAUf = fusion_series()
rl = fs.rocket_leg(0.02, 0.01)
assert abs(Tf[-1] / yr - rl["t"]) < 1e-9 and abs(Xf[-1] / ly - rl["x"]) < 1e-9
for name, label, arr, src in [
    ("BOOST", "laser boost 0.1 g (constant beam power, Doppler-limited) 0 -> 0.23c", (Tb, Xb, Vb, TAUb), "calc_faststop.laser_leg"),
    ("MAGSAIL", "trailing 3,000 km magsail brake 0.23c -> 0.02c, n_i = 0.1 cm^-3 (design assumption)", (Tm, Xm, Vm, TAUm), "calc_shield_sail.magsail via calc_prototype.prop_run(2e7)"),
    ("FUSION", "D-3He fusion brake at 0.01 g (constant proper deceleration) 0.02c -> 0", (Tf, Xf, Vf, TAUf), "calc_faststop.rocket_leg(0.02, 0.01)")]:
    t, x, v, tau = thin(*arr) if name != "FUSION" else arr
    phases.append(dict(name=name, description=label, source=src,
                       t_s=[float(z) for z in t], x_km=[float(z) / 1e3 for z in x], v_km_s=[float(z) / 1e3 for z in v], tau_s=[float(z) for z in tau],
                       duration_s=float(t[-1]), length_km=float(x[-1]) / 1e3, proper_duration_s=float(tau[-1]),
                       full_resolution_steps=len(arr[0])))
prof = dict(format="pythagoras-flight-profile-1.0", notice="DESIGN AND REFERENCE DATA - NOT FLIGHT-CERTIFIED",
            source_document="Pythagoras Concept Design v2.4 §4.7 (20 kt ship, fusion propellant carried); code in /workspace/starship-design",
            assumptions=["Straight-line flight; phases are distance-independent, only the 0.23c coast stretches with distance.",
                         "Magsail drag uses the design's uniform n_i = 0.1 cm^-3 along the whole brake (no real ISM structure).",
                         "Magsail ends at the design code's last integration step (v = %.7f c), the fusion leg starts at exactly 0.02c (%.2f km/s step, from the design code's discretisation)." % (Vm[-1] / c, (0.02 * c - Vm[-1]) / 1e3),
                         "The fusion leg ends at rest in the Solar-System-barycentric frame; matching the target star's own velocity is NOT modelled.",
                         "Flip manoeuvre, sail jettison and E-sail/stellar-wind capture (doc §4.7) are not modelled (assumed instantaneous / outside this profile).",
                         "Every number in this profile is SPECULATIVE design data (doc label [SPECULATIVE])."],
            cruise=dict(name="CRUISE", description="unpowered coast at 0.23c", v_km_s=0.23 * c / 1e3),
            magsail_mass_t=mm / 1e3, constants=dict(c_m_s=c, g_m_s2=g, design_year_s=yr, design_ly_m=ly),
            phases=phases)
s = json.dumps(prof, separators=(",", ":"))
open(OUT, "w").write(s)
print(OUT, len(s) // 1024, "KB", [ (p["name"], len(p["t_s"]), p["duration_s"] / yr, p["length_km"] * 1e3 / ly, p["proper_duration_s"] / yr) for p in phases])
# full-resolution reference series for verification tests (NAV-REQ-011)
np.savez_compressed(os.path.join(os.path.dirname(OUT), "..", "tests", "fixtures", "profile_fullres.npz"),
                    boost=np.vstack([Tb, Xb / 1e3, Vb / 1e3, TAUb]), magsail=np.vstack([Tm, Xm / 1e3, Vm / 1e3, TAUm]))
