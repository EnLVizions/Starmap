"""Build the Pythagoras navigation data package (design/reference data, NOT flight-certified).
Usage: NAV_DEPARTURE_EPOCH=2032.0 ../.venv/bin/python tools/build_nav.py
Inputs : ../starmap_v2.csv (50 ly), ../starmap_v1.2.csv (20 ly), ../pipeline merge (SIMBAD/Gaia cross-match),
         raw/gaia_dr3_astrometry.csv, raw/simbad_astrometry.csv, raw/hipparcos_2007_bright.tsv, raw/simbad_hip_names.csv,
         data/flight_profile.json (tools/make_profile.py), ../raw/lism_redfield_linsky2008.tsv
Outputs: data/*.json|csv, trajectories/*, oem/*.oem, manifest.json, sim_data.js
"""
import os, sys, json, math, re, datetime
import numpy as np, pandas as pd
NAV = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SM = os.path.dirname(NAV)
os.environ.setdefault("STARMAP_DMAX_LY", "50")
sys.path.insert(0, os.path.join(SM, "pipeline")); sys.path.insert(0, NAV)
import navref.navref as nr
from merge import build
from astropy.time import Time

DEP = float(os.environ.get("NAV_DEPARTURE_EPOCH", "2032.0"))
DATA_VERSION = os.environ.get("NAV_DATA_VERSION", "nav-2026.10.17-1")
MC_N = 1000; MC_SEED = 20261017
NOW = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
for d in ("data", "trajectories", "oem"): os.makedirs(os.path.join(NAV, d), exist_ok=True)
J = lambda p, o: open(os.path.join(NAV, p), "w").write(json.dumps(o, indent=1, default=float))

# ------------------------------------------------------------------ star catalogue
st, _, _, _ = build()
v2 = pd.read_csv(os.path.join(SM, "starmap_v2.csv")); v12 = pd.read_csv(os.path.join(SM, "starmap_v1.2.csv"))
st = st[st.sys.isin(set(v2.sys_id))].copy()
ga = pd.read_csv(os.path.join(NAV, "raw/gaia_dr3_astrometry.csv"), dtype={"source_id": str}).set_index("source_id")
sb = pd.read_csv(os.path.join(NAV, "raw/simbad_astrometry.csv")).drop_duplicates("oid").set_index("oid")
sysname = dict(zip(v2.sys_id, v2.system))
def slug(s): return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")
rows, ids = [], set()
for _, s in st.iterrows():
    gid = str(s.gaia_dr3) if isinstance(s.gaia_dr3, str) and s.gaia_dr3 else ""
    use_gaia = s.astrom_src == "Gaia DR3" and gid in ga.index
    r = dict(id=None, name=s["name"], simbad_main_id=s.main_id, simbad_oid=int(s.oid), otype=s.otype, sys_id=int(s.sys), system=sysname.get(s.sys, ""),
             sp_type=s.sp_type if isinstance(s.sp_type, str) else "", gaia_dr3_id=gid, hip=s.hip if isinstance(s.hip, str) else "")
    if use_gaia:
        g = ga.loc[gid]
        r.update(ref_epoch=float(g.ref_epoch), astrometry_source="Gaia DR3 (ESA/DPAC)", ra_deg=g.ra, dec_deg=g.dec, ra_error_mas=g.ra_error, dec_error_mas=g.dec_error,
                 parallax_mas=g.parallax, parallax_error_mas=g.parallax_error, pmra_mas_yr=g.pmra, pmra_error_mas_yr=g.pmra_error, pmdec_mas_yr=g.pmdec,
                 pmdec_error_mas_yr=g.pmdec_error, pm_source="Gaia DR3", parallax_pmra_corr=g.parallax_pmra_corr, parallax_pmdec_corr=g.parallax_pmdec_corr,
                 pmra_pmdec_corr=g.pmra_pmdec_corr, ruwe=g.ruwe)
    else:
        if s.oid not in sb.index: continue
        b = sb.loc[s.oid]
        # SIMBAD pm error ellipse (maj, min, PA) -> sigma_pmra*, sigma_pmdec, correlation
        th = math.radians(b.pm_err_angle) if pd.notna(b.pm_err_angle) else 0.0
        M, m = (b.pm_err_maj, b.pm_err_min) if pd.notna(b.pm_err_maj) else (np.nan, np.nan)
        caa = (M * math.sin(th)) ** 2 + (m * math.cos(th)) ** 2; cdd = (M * math.cos(th)) ** 2 + (m * math.sin(th)) ** 2
        cad = (M ** 2 - m ** 2) * math.sin(th) * math.cos(th)
        r.update(ref_epoch=2000.0, astrometry_source=f"SIMBAD/CDS (coords {b.coo_bibcode}; parallax {s.astrom_src})", ra_deg=b.ra, dec_deg=b.dec,
                 ra_error_mas=b.coo_err_maj, dec_error_mas=b.coo_err_min, parallax_mas=s.plx, parallax_error_mas=s.plx_err,
                 pmra_mas_yr=b.pmra, pmra_error_mas_yr=math.sqrt(caa) if pd.notna(M) else np.nan, pmdec_mas_yr=b.pmdec,
                 pmdec_error_mas_yr=math.sqrt(cdd) if pd.notna(M) else np.nan, pm_source=f"SIMBAD ({b.pm_bibcode})",
                 parallax_pmra_corr=0.0, parallax_pmdec_corr=0.0, pmra_pmdec_corr=cad / math.sqrt(caa * cdd) if pd.notna(M) and caa * cdd > 0 else 0.0, ruwe=np.nan)
    rv_ok = pd.notna(s.rv) and pd.notna(r["pmra_mas_yr"]) and pd.notna(r["pmdec_mas_yr"])
    r.update(rv_km_s=s.rv if rv_ok else None, rv_error_km_s=s.rv_err if rv_ok and pd.notna(s.rv_err) else None, rv_source=s.rv_src if rv_ok else "")
    if not (pd.notna(r["parallax_mas"]) and r["parallax_mas"] > 0): continue
    base = slug(r["name"]) or str(r["simbad_oid"]); k = base; n = 2
    while k in ids: k = f"{base}-{n}"; n += 1
    ids.add(k); r["id"] = k
    pos, vel = nr.astrometric_to_cartesian(r["ra_deg"], r["dec_deg"], r["parallax_mas"], r["pmra_mas_yr"] if pd.notna(r["pmra_mas_yr"]) else 0.0,
                                           r["pmdec_mas_yr"] if pd.notna(r["pmdec_mas_yr"]) else 0.0, r["rv_km_s"])
    r["pos_km"] = list(pos); r["vel_km_s"] = None if vel is None else list(vel)
    rows.append(r)
cat_rows = rows
print("catalogue stars", len(cat_rows), "with full velocity", sum(r["vel_km_s"] is not None for r in cat_rows))

# ------------------------------------------------------------------ destinations: union of v2 top-10 (50 ly) and v1.2 top-10 (20 ly)
by_name = {(r["sys_id"], r["name"]): r for r in cat_rows}
name_sys = {}
for r in cat_rows: name_sys.setdefault(r["name"], r)
dest = {}
for lab, df in (("v2", v2), ("v1.2", v12)):
    for _, row in df.sort_values("rank").head(10).iterrows():
        r = name_sys.get(row.destination_component)
        if r is None: raise SystemExit(f"destination component {row.destination_component} not in catalogue")
        did = r["id"]
        d = dest.setdefault(did, dict(id=did, star_id=did, name=row.destination_component, system=row.system, rank_v2=None, rank_v1_2=None,
                                      best_planet=row.best_planet, hz_flag=row.hz_flag, sys_id=int(r["sys_id"])))
        d["rank_v2" if lab == "v2" else "rank_v1_2"] = int(row["rank"])
dests = sorted(dest.values(), key=lambda d: (d["rank_v2"] or 99, d["rank_v1_2"] or 99))
cat_json = dict(format=nr.CATALOG_FORMAT, data_version=DATA_VERSION, created_utc=NOW, frame="ICRS, barycentric (BCRS axes), Cartesian",
                units=dict(pos_km="km", vel_km_s="km/s", ref_epoch="Julian year TDB", angles="deg", parallax="mas", proper_motion="mas/yr (pmra = mu_alpha*)"),
                light_time_correction=True,
                light_time_note="pos_km is the catalogue (as-observed, astrometric) position at ref_epoch. navref.star_state() adds v*d/c to get the geometric position.",
                notice="DESIGN AND REFERENCE DATA - NOT FLIGHT-CERTIFIED",
                stars=[{k: (None if isinstance(v, float) and not math.isfinite(v) else v) for k, v in r.items()} for r in cat_rows], destinations=dests)
J("data/star_catalog.json", cat_json)
cat = nr.validate_catalog(json.loads(json.dumps(cat_json, default=float)))
prof = nr.load_profile(os.path.join(NAV, "data/flight_profile.json"))

# CSV catalogue with Cartesian in ly/AU/pc and the position at 2016.0 and at departure
LY, AU, PC = nr.LY_KM, nr.AU_KM, nr.PC_KM
out = []
for r in cat_rows:
    c = {k: v for k, v in r.items() if k not in ("pos_km", "vel_km_s")}
    p = np.array(r["pos_km"]); d = np.linalg.norm(p)
    c.update(dist_ly=d / LY, dist_err_ly=d / LY * r["parallax_error_mas"] / r["parallax_mas"] if pd.notna(r["parallax_error_mas"]) else None)
    for u, f in (("km", 1.0), ("ly", LY), ("au", AU), ("pc", PC)):
        for i, a in enumerate("xyz"): c[f"{a}_{u}_refepoch"] = p[i] / f
    if r["vel_km_s"] is not None:
        v = np.array(r["vel_km_s"])
        for i, a in enumerate("xyz"): c[f"v{a}_km_s"] = v[i]
        for i, a in enumerate("xyz"): c[f"v{a}_au_yr"] = v[i] * nr.JYEAR_S / AU
        c["speed_km_s"] = float(np.linalg.norm(v))
        for ep, tag in ((2016.0, "2016"), (DEP, "departure")):
            q, _ = nr.star_state(cat, r["id"], ep, light_time=False)
            for i, a in enumerate("xyz"): c[f"{a}_ly_astrometric_{tag}"] = q[i] / LY
    else:
        c["velocity_note"] = "radial velocity unknown: no 3-D velocity; position not propagated"
    out.append(c)
pd.DataFrame(out).to_csv(os.path.join(NAV, "data/star_catalog.csv"), index=False)

# ------------------------------------------------------------------ intercepts (+ Monte-Carlo uncertainty) and trajectories
rng = np.random.default_rng(MC_SEED)
def mc_intercept(did):
    r = next(x for x in cat_rows if x["id"] == did)
    sig = [r["parallax_error_mas"], r["pmra_error_mas_yr"], r["pmdec_error_mas_yr"], r["rv_error_km_s"] or 0.0]
    corr = np.eye(4); corr[0, 1] = corr[1, 0] = r["parallax_pmra_corr"] or 0; corr[0, 2] = corr[2, 0] = r["parallax_pmdec_corr"] or 0
    corr[1, 2] = corr[2, 1] = r["pmra_pmdec_corr"] or 0
    cov = corr * np.outer(sig, sig); mu = [r["parallax_mas"], r["pmra_mas_yr"], r["pmdec_mas_yr"], r["rv_km_s"]]
    S = rng.multivariate_normal(mu, cov, size=MC_N)
    nom = nr.intercept(cat, prof, did, DEP); P = []; T = []
    for k in range(MC_N):
        pos, vel = nr.astrometric_to_cartesian(r["ra_deg"], r["dec_deg"], S[k, 0], S[k, 1], S[k, 2], S[k, 3])
        c2 = dict(cat); c2["stars"] = dict(cat["stars"]); c2["stars"][did] = dict(cat["stars"][did], pos_km=pos, vel_km_s=vel)
        ic = nr.intercept(c2, prof, did, DEP); P.append(ic["aim_point_km"]); T.append(ic["arrival_epoch"])
    P = np.array(P) - np.array(nom["aim_point_km"]); u = np.array(nom["aim_unit"])
    rad = P @ u; tr = P - np.outer(rad, u)
    return dict(n_samples=MC_N, seed=MC_SEED, sigma_along_line_of_sight_au=float(np.std(rad) / AU),
                sigma_transverse_au=float(np.sqrt(np.mean(np.sum(tr ** 2, 1)) / 2) / AU),
                sigma_arrival_epoch_days=float(np.std(T) * 365.25),
                note="1-sigma spread of the intercept point from catalogue parallax, proper-motion and RV errors (Gaia correlations used; RA/Dec errors neglected, < 0.1 mas). Stellar orbital motion in multiples (e.g. Proxima around alpha Cen AB) is NOT included.")
def jy_iso(jy): return Time(jy, format="jyear", scale="tdb").isot[:23]
intercepts, waypoints, hazards = [], [], []
lism = pd.read_csv(os.path.join(SM, "raw/lism_redfield_linsky2008.tsv"), sep="\t", comment="#", header=None, dtype=str, keep_default_na=False)
lism.columns = ["sys", "l", "b", "traverses", "near", "status"][:lism.shape[1]]
lism = lism[lism.sys.str.fullmatch(r"\d+")].drop_duplicates("sys", keep="last").set_index("sys")
gamma_c = prof["gamma_cruise"]; mp_MeV = 938.27208816
for d in dests:
    did = d["id"]; ic = nr.intercept(cat, prof, did, DEP); unc = mc_intercept(did)
    sysrow = v2[v2.sys_id == d["sys_id"]].iloc[0]
    rec = dict(dest_id=did, name=d["name"], system=d["system"], rank_v2=d["rank_v2"], rank_v1_2=d["rank_v1_2"], best_planet=d["best_planet"], hz_flag=d["hz_flag"],
               departure_epoch_jyr=DEP, departure_utc_like_tdb=jy_iso(DEP), arrival_epoch_jyr=ic["arrival_epoch"], arrival_tdb=jy_iso(ic["arrival_epoch"]),
               trip_earth_yr=ic["arrival_epoch"] - DEP, trip_proper_yr=ic["arrival_epoch_proper"] - DEP,
               flight_distance_ly=ic["flight_distance_km"] / LY, aim_point_km=list(ic["aim_point_km"]), aim_point_ly=[x / LY for x in ic["aim_point_km"]],
               aim_unit_icrs=list(ic["aim_unit"]),
               aim_ra_deg=math.degrees(math.atan2(ic["aim_unit"][1], ic["aim_unit"][0])) % 360, aim_dec_deg=math.degrees(math.asin(ic["aim_unit"][2])),
               aim_shift_vs_apparent_arcsec=ic["aim_shift_vs_apparent_arcsec"], aim_shift_vs_geometric_departure_arcsec=ic["aim_shift_vs_geometric_departure_arcsec"],
               miss_if_aimed_at_apparent_position_au=ic["miss_if_aimed_at_apparent_km"] / AU,
               target_displacement_during_flight_au=ic["displacement_since_departure_km"] / AU, light_time_correction_au=ic["light_time_shift_km"] / AU,
               target_velocity_km_s=list(ic["target_velocity_km_s"]), delta_v_to_match_target_km_s=ic["delta_v_to_match_target_km_s"],
               iterations=ic["iterations"], uncertainty=unc)
    intercepts.append(rec)
    # waypoints at phase boundaries
    wps = []
    for k, ph in enumerate(ic["timeline"]):
        for edge in ("start", "end"):
            if edge == "start" and k > 0: continue
            t = ph[f"t_{edge}_s"]; s = nr.nav_state(cat, prof, did, DEP, t, "earth")
            label = {0: "DEPARTURE", 1: "END_BOOST/START_CRUISE", 2: "END_CRUISE/START_MAGSAIL", 3: "END_MAGSAIL/START_FUSION", 4: "ARRIVAL"}[k + (1 if edge == "end" else 0)]
            wps.append(dict(waypoint=label, epoch_tdb_jyr=s["epoch_tdb_jyr"], epoch_tdb=jy_iso(s["epoch_tdb_jyr"]), earth_elapsed_yr=t / nr.JYEAR_S,
                            proper_elapsed_yr=s["proper_elapsed_s"] / nr.JYEAR_S, beta=s["beta"], distance_flown_ly=s["distance_flown_km"] / LY,
                            pos_km=list(s["ship_pos_km"]), vel_km_s=list(s["ship_vel_km_s"])))
    waypoints.append(dict(dest_id=did, waypoints=wps))
    # time-stamped trajectory samples (Earth-time grid; proper time given per sample)
    grid = []
    steps = {"BOOST": 0.05, "CRUISE": 0.5, "MAGSAIL": 0.1, "FUSION": 0.05}
    for ph in ic["timeline"]:
        a, b = ph["t_start_s"], ph["t_end_s"]; n = max(2, int(math.ceil((b - a) / (steps[ph["phase"]] * nr.JYEAR_S))))
        seg = [a + (b - a) * i / n for i in range(n + 1)]
        grid.append((ph["phase"], seg))
    samples = []
    for phase, seg in grid:
        for t in seg:
            s = nr.nav_state(cat, prof, did, DEP, t, "earth")
            # label boundary points with the phase whose segment they belong to
            samples.append(dict(phase=phase, epoch_tdb=jy_iso(s["epoch_tdb_jyr"]), epoch_tdb_jyr=s["epoch_tdb_jyr"], earth_elapsed_s=t,
                                proper_elapsed_s=s["proper_elapsed_s"], earth_elapsed_yr=t / nr.JYEAR_S, proper_elapsed_yr=s["proper_elapsed_s"] / nr.JYEAR_S,
                                x_km=s["ship_pos_km"][0], y_km=s["ship_pos_km"][1], z_km=s["ship_pos_km"][2],
                                vx_km_s=s["ship_vel_km_s"][0], vy_km_s=s["ship_vel_km_s"][1], vz_km_s=s["ship_vel_km_s"][2],
                                x_ly=s["ship_pos_km"][0] / LY, y_ly=s["ship_pos_km"][1] / LY, z_ly=s["ship_pos_km"][2] / LY,
                                beta=s["beta"], gamma=s["gamma"], distance_flown_ly=s["distance_flown_km"] / LY, distance_remaining_ly=s["distance_remaining_km"] / LY))
    df = pd.DataFrame(samples); df.to_csv(os.path.join(NAV, f"trajectories/{did}.csv"), index=False)
    J(f"trajectories/{did}.json", dict(notice="DESIGN AND REFERENCE DATA - NOT FLIGHT-CERTIFIED", dest_id=did, data_version=DATA_VERSION, departure_epoch_jyr=DEP,
                                       frame="ICRS barycentric", time_scales=dict(epoch="TDB (Julian years / ISO)", proper="ship proper time since departure"),
                                       intercept=rec, waypoints=wps, samples=samples))
    # OEM (CCSDS 502.0-B-3 style), one segment per phase
    L = ["CCSDS_OEM_VERS = 3.0", f"COMMENT DESIGN AND REFERENCE DATA - NOT FLIGHT-CERTIFIED. Pythagoras nav package {DATA_VERSION}, navref {nr.NAVREF_VERSION}",
         "COMMENT OEM-style file generated from a design flight profile (Pythagoras Concept Design v2.4 s4.7); not produced or validated by any CCSDS tool.",
         "COMMENT Ship proper time is not an OEM time system: per-segment proper-time ranges are given in COMMENT lines; per-sample values in the CSV/JSON.",
         f"CREATION_DATE = {NOW}", "ORIGINATOR = PYTHAGORAS-STARMAP-NAV (design study)", ""]
    for phase, seg in grid:
        s0 = nr.nav_state(cat, prof, did, DEP, seg[0], "earth"); s1 = nr.nav_state(cat, prof, did, DEP, seg[-1], "earth")
        L += ["META_START", f"OBJECT_NAME = PYTHAGORAS-TO-{did.upper()}", "OBJECT_ID = DESIGN-STUDY-NONE", "CENTER_NAME = SOLAR SYSTEM BARYCENTER", "REF_FRAME = ICRF",
              "TIME_SYSTEM = TDB", f"START_TIME = {jy_iso(s0['epoch_tdb_jyr'])}", f"STOP_TIME = {jy_iso(s1['epoch_tdb_jyr'])}", "INTERPOLATION = HERMITE", "INTERPOLATION_DEGREE = 3",
              "META_STOP", f"COMMENT PHASE = {phase}", f"COMMENT PROPER_TIME_SINCE_DEPARTURE_YR = {s0['proper_elapsed_s']/nr.JYEAR_S:.9f} TO {s1['proper_elapsed_s']/nr.JYEAR_S:.9f}"]
        for t in seg:
            s = nr.nav_state(cat, prof, did, DEP, t, "earth"); p, v = [z + 0.0 for z in s["ship_pos_km"]], [z + 0.0 for z in s["ship_vel_km_s"]]
            L.append(f"{jy_iso(s['epoch_tdb_jyr'])} {p[0]:.12e} {p[1]:.12e} {p[2]:.12e} {v[0]:.12e} {v[1]:.12e} {v[2]:.12e}")
        L.append("")
    open(os.path.join(NAV, f"oem/{did}.oem"), "w").write("\n".join(L))
    # hazards
    lr = lism.loc[str(d["sys_id"])] if str(d["sys_id"]) in lism.index else None
    D = ic["flight_distance_km"] * 1e5  # cm
    hazards.append(dict(dest_id=did, system=d["system"], lism_model="Redfield & Linsky 2008 (ApJ 673, 283) Kinematic Calculator",
                        lism_sight_line_l_b_deg=None if lr is None else [float(lr.l), float(lr.b)], lism_lookup_status=None if lr is None else lr.status,
                        clouds_traversed=[] if lr is None or lr.traverses == "none" else lr.traverses.split(","),
                        clouds_near_20deg=[] if lr is None or not lr.near else lr.near.split(","),
                        projection_only=True,
                        projection_note="The model gives which clouds the sight line passes through in projection only: no distances to cloud boundaries, so a 'traversed' cloud may lie beyond the target and the order of crossings is unknown.",
                        route_note=sysrow.route_note,
                        assumed_ism_ion_density_cm3=0.1, assumed_density_source="Pythagoras Concept Design v2.4: magsail model n_i = 0.1 cm^-3 (calc_shield_sail.magsail default)",
                        assumed_column_density_cm2=0.1 * D, column_density_note="= assumed n_i x flight distance (derived, uniform-density assumption)",
                        ism_proton_energy_ship_frame_MeV=(gamma_c - 1) * mp_MeV, proton_energy_note="kinetic energy of an ISM proton in the ship frame at 0.23c = (gamma-1) m_p c^2 (design doc s2.7 quotes 25.8 MeV)",
                        dust_hazard="unknown (no direction-dependent dust data; see star map SOURCES.md s6)"))
J("data/intercepts.json", dict(notice="DESIGN AND REFERENCE DATA - NOT FLIGHT-CERTIFIED", data_version=DATA_VERSION, departure_epoch_jyr=DEP, intercepts=intercepts))
pd.DataFrame([{k: v for k, v in r.items() if not isinstance(v, (list, dict))} | {f"unc_{k}": v for k, v in r["uncertainty"].items() if k != "note"} for r in intercepts]).to_csv(os.path.join(NAV, "data/intercepts.csv"), index=False)
J("data/waypoints.json", dict(notice="DESIGN AND REFERENCE DATA - NOT FLIGHT-CERTIFIED", data_version=DATA_VERSION, departure_epoch_jyr=DEP, destinations=waypoints))
pd.DataFrame([dict(dest_id=w["dest_id"], **{k: v for k, v in p.items() if k not in ("pos_km", "vel_km_s")},
                   x_km=p["pos_km"][0], y_km=p["pos_km"][1], z_km=p["pos_km"][2], vx_km_s=p["vel_km_s"][0], vy_km_s=p["vel_km_s"][1], vz_km_s=p["vel_km_s"][2])
              for w in waypoints for p in w["waypoints"]]).to_csv(os.path.join(NAV, "data/waypoints.csv"), index=False)
J("data/route_hazards.json", dict(notice="DESIGN AND REFERENCE DATA - NOT FLIGHT-CERTIFIED", data_version=DATA_VERSION, hazards=hazards))
pd.DataFrame([{k: (";".join(v) if isinstance(v, list) and all(isinstance(z, str) for z in v) else v) for k, v in h.items()} for h in hazards]).to_csv(os.path.join(NAV, "data/route_hazards.csv"), index=False)

# ------------------------------------------------------------------ guide stars (Hipparcos 2007) + aberration / Doppler
hp = pd.read_csv(os.path.join(NAV, "raw/hipparcos_2007_bright.tsv"), sep="\t", comment="#", skiprows=0, dtype=str)
hp = hp[hp.HIP.str.strip().str.isdigit()].copy()
for c in ["RArad", "DErad", "Plx", "e_Plx", "pmRA", "e_pmRA", "pmDE", "e_pmDE", "e_RArad", "e_DErad", "Hpmag", "B-V", "Sn"]: hp[c] = pd.to_numeric(hp[c], errors="coerce")
hp["HIP"] = hp.HIP.str.strip().astype(int)
nm = pd.read_csv(os.path.join(NAV, "raw/simbad_hip_names.csv"))
nm["HIP"] = nm.hip_id.str.replace("HIP ", "").astype(int)
names = nm.groupby("HIP").agg(main_id=("main_id", "first"), sp_type=("sp_type", "first"), proper_name=("name_id", lambda s: next((x[5:] for x in s if isinstance(x, str)), ""))).reset_index()
GS = hp[(hp.Hpmag < 3.5) & (hp.Sn == 5) & (hp.e_RArad < 1.0) & (hp.e_DErad < 1.0) & (hp.Plx > 0)].merge(names, on="HIP", how="left")
beta = 0.23; gam = 1 / math.sqrt(1 - beta ** 2)
def bv_teff(bv):  # Ballesteros (2012, EPL 97, 34) black-body approximation
    return 4600 * (1 / (0.92 * bv + 1.7) + 1 / (0.92 * bv + 0.62))
gs_rows = []
for _, g in GS.iterrows():
    ra, de = math.radians(g.RArad), math.radians(g.DErad)
    u0 = np.array([math.cos(de) * math.cos(ra), math.cos(de) * math.sin(ra), math.sin(de)]); dpc = 1000 / g.Plx
    gs_rows.append(dict(HIP=g.HIP, name=(g.proper_name if isinstance(g.proper_name, str) and g.proper_name else str(g.main_id).replace("* ", "").strip()), simbad_main_id=g.main_id, sp_type=g.sp_type, Hpmag=g.Hpmag, B_V=g["B-V"],
                        teff_bv_K=bv_teff(g["B-V"]) if pd.notna(g["B-V"]) else None, ra_deg_J1991_25=g.RArad, dec_deg_J1991_25=g.DErad,
                        ra_error_mas=g.e_RArad, dec_error_mas=g.e_DErad, parallax_mas=g.Plx, parallax_error_mas=g.e_Plx, pmra_mas_yr=g.pmRA,
                        pmra_error_mas_yr=g.e_pmRA, pmdec_mas_yr=g.pmDE, pmdec_error_mas_yr=g.e_pmDE, dist_ly=dpc * nr.PC_KM / LY,
                        x_ly=u0[0] * dpc * PC / LY, y_ly=u0[1] * dpc * PC / LY, z_ly=u0[2] * dpc * PC / LY, hip_solution_type=int(g.Sn),
                        parallax_shift_useful_for_position_fix=bool(g.Plx > 20)))
gsd = pd.DataFrame(gs_rows); gsd.to_csv(os.path.join(NAV, "data/guide_stars.csv"), index=False)
# generic aberration/Doppler table at 0.23c
ab = []
for th in range(0, 181, 5):
    c0 = math.cos(math.radians(th)); cp = (c0 + beta) / (1 + beta * c0); thp = math.degrees(math.acos(max(-1, min(1, cp))))
    dlt = gam * (1 + beta * c0)
    ab.append(dict(rest_angle_from_apex_deg=th, ship_angle_from_apex_deg=thp, aberration_shift_deg=th - thp, doppler_factor=dlt,
                   wavelength_factor=1 / dlt, color_temperature_factor=dlt, bolometric_flux_factor_delta4=dlt ** 4))
pd.DataFrame(ab).to_csv(os.path.join(NAV, "data/aberration_doppler_0.23c.csv"), index=False)
# per destination at cruise midpoint: apparent guide-star directions
per = []
for d in dests:
    ic = nr.intercept(cat, prof, d["id"], DEP); tl = ic["timeline"][1]; tm = 0.5 * (tl["t_start_s"] + tl["t_end_s"])
    s = nr.nav_state(cat, prof, d["id"], DEP, tm, "earth"); P = np.array(s["ship_pos_km"]) / LY; U = np.array(ic["aim_unit"])
    for g in gs_rows:
        r = np.array([g["x_ly"], g["y_ly"], g["z_ly"]]) - P; dist = np.linalg.norm(r); n = r / dist
        c0 = float(n @ U); th = math.degrees(math.acos(max(-1, min(1, c0)))); cp = (c0 + beta) / (1 + beta * c0)
        thp = math.degrees(math.acos(max(-1, min(1, cp)))); dlt = gam * (1 + beta * c0)
        u_sun = np.array([g["x_ly"], g["y_ly"], g["z_ly"]]) / math.hypot(g["x_ly"], g["y_ly"], g["z_ly"])
        per.append(dict(dest_id=d["id"], HIP=g["HIP"], name=g["name"], cruise_mid_epoch_tdb_jyr=s["epoch_tdb_jyr"],
                        parallax_shift_from_sun_view_arcsec=math.degrees(math.acos(max(-1, min(1, float(n @ u_sun))))) * 3600,
                        angle_from_velocity_rest_deg=th, angle_from_velocity_ship_deg=thp, aberration_shift_deg=th - thp, doppler_factor=dlt,
                        apparent_teff_K=g["teff_bv_K"] * dlt if g["teff_bv_K"] else None))
pd.DataFrame(per).to_csv(os.path.join(NAV, "data/guide_star_views_cruise.csv"), index=False)
print("guide stars", len(gs_rows))

# ------------------------------------------------------------------ sim data
skyh = hp[(hp.Hpmag < 6.0) & (hp.Plx.notna())]
cmap = {"O": 30000, "B": 15000, "A": 9000, "F": 6800, "G": 5600, "K": 4400, "M": 3200, "L": 1900, "T": 1100, "Y": 450, "D": 10000}
hips_in_cat = set()
for r in cat_rows:
    m = re.match(r"HIP (\d+)", r["hip"] or "");
    if m: hips_in_cat.add(int(m.group(1)))
sky = []
for _, g in skyh.iterrows():
    if g.HIP in hips_in_cat: continue
    ra, de = math.radians(g.RArad), math.radians(g.DErad); dl = (1000 / g.Plx) * PC / LY if g.Plx > 0.5 else 1e5
    sky.append([round(math.cos(de) * math.cos(ra) * dl, 4), round(math.cos(de) * math.sin(ra) * dl, 4), round(math.sin(de) * dl, 4), round(g.Hpmag, 2),
                int(bv_teff(g["B-V"])) if pd.notna(g["B-V"]) else 5600])
for r in cat_rows:
    gm = st.loc[st.oid == r["simbad_oid"], ["gmag", "vmag", "bp_rp"]].iloc[0]
    mag = gm.vmag if pd.notna(gm.vmag) else gm.gmag
    if not pd.notna(mag): continue
    p = np.array(r["pos_km"]) / LY; cls = (r["sp_type"] or "?")[:1].upper()
    sky.append([round(p[0], 4), round(p[1], 4), round(p[2], 4), round(float(mag), 2), cmap.get(cls, 4000)])
# blackbody -> sRGB lookup (CIE 1931 2-deg CMF, multi-lobe Gaussian fit of Wyman, Sloan & Shirley 2013, JCGT 2(2))
lam = np.arange(380, 781, 5.0)
def g_(x, mu, s1, s2): return np.exp(-0.5 * ((x - mu) / np.where(x < mu, s1, s2)) ** 2)
xb = 1.056 * g_(lam, 599.8, 37.9, 31.0) + 0.362 * g_(lam, 442.0, 16.0, 26.7) - 0.065 * g_(lam, 501.1, 20.4, 26.2)
yb = 0.821 * g_(lam, 568.8, 46.9, 40.5) + 0.286 * g_(lam, 530.9, 16.3, 31.1)
zb = 1.217 * g_(lam, 437.0, 11.8, 36.0) + 0.681 * g_(lam, 459.0, 26.0, 13.8)
Ts = np.geomspace(300, 200000, 160); rgb = []
for T in Ts:
    B = 1 / (lam ** 5 * (np.exp(1.4388e7 / (lam * T)) - 1)); X, Y, Z = (B * xb).sum(), (B * yb).sum(), (B * zb).sum()
    M = np.array([[3.2406, -1.5372, -0.4986], [-0.9689, 1.8758, 0.0415], [0.0557, -0.2040, 1.0570]]) @ np.array([X, Y, Z])
    M = np.clip(M, 0, None); M = M / M.max(); M = np.where(M <= 0.0031308, 12.92 * M, 1.055 * M ** (1 / 2.4) - 0.055)
    rgb.append([round(float(z), 3) for z in M])
nearby = [[round(x / LY, 3) for x in r["pos_km"]] for r in cat_rows]
simd = dict(notice="DESIGN AND REFERENCE DATA - NOT FLIGHT-CERTIFIED", data_version=DATA_VERSION, departure_epoch=DEP, c_km_s=nr.C_KM_S, jyear_s=nr.JYEAR_S, ly_km=LY,
            v_cruise_c=0.23, intercepts=intercepts, hazards=hazards,
            trajectories={d["id"]: pd.read_csv(os.path.join(NAV, f"trajectories/{d['id']}.csv"))[["phase", "earth_elapsed_yr", "proper_elapsed_yr", "epoch_tdb_jyr", "x_ly", "y_ly", "z_ly", "beta", "distance_flown_ly", "distance_remaining_ly"]].round(9).values.tolist() for d in dests},
            sky=sky, nearby=nearby, bb_T=[round(float(t), 1) for t in Ts], bb_rgb=rgb)
open(os.path.join(NAV, "sim_data.js"), "w").write("window.NAVSIM=" + json.dumps(simd, separators=(",", ":"), default=float) + ";")
# ------------------------------------------------------------------ manifest
files = sorted([os.path.relpath(os.path.join(dp, f), NAV) for dp, _, fs_ in os.walk(NAV) for f in fs_ if dp.split(os.sep)[-1] in ("data", "trajectories", "oem")])
J("manifest.json", dict(package="pythagoras-nav", data_version=DATA_VERSION, navref_version=nr.NAVREF_VERSION, created_utc=NOW, departure_epoch_jyr=DEP,
                        notice="DESIGN AND REFERENCE DATA - NOT FLIGHT-CERTIFIED", files={f: nr.sha256_file(os.path.join(NAV, f)) for f in files}))
print("done", len(dests), "destinations")
